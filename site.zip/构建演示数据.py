from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


DEMO_DIR = Path(__file__).resolve().parent
PROJECT_DIR = DEMO_DIR / "research/01 输入数据/imported"


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def read_csv(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def number(value):
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return value


def typed_rows(rows):
    result = []
    for row in rows:
        converted = {}
        for key, value in row.items():
            candidate = number(value)
            if candidate == "True":
                candidate = True
            elif candidate == "False":
                candidate = False
            converted[key] = candidate
        result.append(converted)
    return result


def sha256(path: Path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


paths = {
    "assets": PROJECT_DIR / "10_GIS_and_3D/flatirons_geospatial_twin/flatirons_assets.geojson",
    "roads": PROJECT_DIR / "10_GIS_and_3D/flatirons_geospatial_twin/flatirons_campus_roads.geojson",
    "osm_manifest": PROJECT_DIR / "04_Raw_Data/geospatial/flatirons_osm/来源清单.json",
    "asset_master": PROJECT_DIR / "03_Asset_Register/asset_master.csv",
    "equipment": PROJECT_DIR / "03_Asset_Register/official_wind_equipment_parameters.csv",
    "facts": PROJECT_DIR / "03_Asset_Register/reference_facility_facts.csv",
    "m2": PROJECT_DIR / "05_Standardized_Data/observations/M2/NWTC_M2_20261017_20261018_standardized.csv",
    "forecast": PROJECT_DIR / "11_Audit_Reports/00.07_weather_risk_screen.csv",
    "scenario": PROJECT_DIR / "07_Models/capacity_weather_scenario/wind_pv_capacity_weather_scenario.csv",
    "scenario_parameters": PROJECT_DIR / "07_Models/capacity_weather_scenario/scenario_parameters.json",
    "alerts": PROJECT_DIR / "04_Raw_Data/weather/nws_alerts/flatirons_active_alerts_latest.json",
    "health": PROJECT_DIR / "11_Audit_Reports/00.09_public_device_health_metrics.csv",
    "imagery": DEMO_DIR / "网站资源 Web Assets/flatirons_world_imagery.png",
}

missing = [str(path) for path in paths.values() if not path.exists()]
if missing:
    raise FileNotFoundError("Required input files are missing:\n" + "\n".join(missing))

assets = read_json(paths["assets"])
roads = read_json(paths["roads"])
osm_manifest = read_json(paths["osm_manifest"])
asset_master = typed_rows(read_csv(paths["asset_master"]))
equipment = typed_rows(read_csv(paths["equipment"]))
facts = typed_rows(read_csv(paths["facts"]))
m2_rows = typed_rows(read_csv(paths["m2"]))
forecast = typed_rows(read_csv(paths["forecast"]))
scenario = typed_rows(read_csv(paths["scenario"]))
scenario_parameters = read_json(paths["scenario_parameters"])
alerts = read_json(paths["alerts"])
health = typed_rows(read_csv(paths["health"]))
egras_metrics_path = DEMO_DIR / "research/04 实验结果/egras_metrics.json"
egras_audit_path = DEMO_DIR / "research/02 状态更新引擎/egras_state_audit.json"
warning_metrics_path = DEMO_DIR / "research/04 实验结果/extreme_wind_evaluation.json"
egras_metrics = read_json(egras_metrics_path) if egras_metrics_path.exists() else {}
egras_audit = read_json(egras_audit_path) if egras_audit_path.exists() else {"active": [], "events": []}
warning_metrics = read_json(warning_metrics_path) if warning_metrics_path.exists() else None
external_metrics_path = DEMO_DIR / "research/04 实验结果/external_2026_evaluation.json"
external_metrics = read_json(external_metrics_path) if external_metrics_path.exists() else None
site_state_path = DEMO_DIR / "research/02 状态更新引擎/site_state_audit.json"
site_state = read_json(site_state_path) if site_state_path.exists() else {"active": [], "history": []}

latest_observation = m2_rows[-1]
latest_observation["ghi_physical_wm2"] = max(0.0, float(latest_observation["ghi_wm2"]))
latest_observation["ghi_quality_note"] = (
    "The raw nighttime GHI is slightly negative because of sensor zero offset; "
    "the capacity-level scenario clips it to 0 W/m2."
)

hourly_observations = [
    {
        "observation_day": row["observation_day"],
        "observation_time_mst": row["observation_time_mst"],
        "wind_speed_80m_mps": row["wind_speed_80m_mps"],
        "wind_speed_10m_mps": row["wind_speed_10m_mps"],
        "ghi_wm2": row["ghi_wm2"],
        "temperature_80m_c": row["temperature_80m_c"],
        "relative_humidity_pct": row["relative_humidity_pct"],
    }
    for row in m2_rows
    if int(row["observation_time_mst"]) % 100 == 0
]

observed_scenario = [row for row in scenario if row["record_type"] == "observed_weather"][-1]
forecast_scenario = {
    int(row["forecast_hour"]): row
    for row in scenario
    if row["record_type"] == "forecast_weather"
}

forecast_records = []
for row in forecast:
    lead = int(row["forecast_hour"])
    scenario_row = forecast_scenario.get(lead, {})
    forecast_records.append(
        {
            "lead_hours": lead,
            "valid_time_utc": datetime.fromisoformat(row["valid_time_utc"]).replace(tzinfo=timezone.utc).isoformat(),
            "gfs_wind_speed_10m_mps": row["gfs_wind_speed_10m_mps"],
            "m2_observed_wind_speed_10m_mps": row["m2_observed_wind_speed_10m_mps"],
            "observation_available": row["observation_available"],
            "wind_speed_80m_screen_mps": row["wind_speed_80m_screen_mps"],
            "three_hour_change_mps": row["three_hour_change_mps"],
            "high_wind_weather_screen": row["high_wind_weather_screen"],
            "rapid_change_weather_screen": row["rapid_change_weather_screen"],
            "source_gap_screen": row["source_gap_screen"],
            "wind_power_mw_scenario": scenario_row.get("wind_power_mw_scenario"),
            "risk_output_role": "weather-only advisory screen",
            "device_action_allowed": False,
        }
    )

kind_counts = {}
for feature in assets["features"]:
    kind = feature.get("properties", {}).get("kind", "unknown")
    kind_counts[kind] = kind_counts.get(kind, 0) + 1

demo_data = {
    "schema_version": "1.0.0",
    "generated_at_utc": datetime.now(timezone.utc).isoformat(),
    "site": {
        "name": "NLR Flatirons Campus",
        "display_name": "Flatirons Renewable Energy Research Campus",
        "center": {"longitude": -105.225, "latitude": 39.9095},
        "imagery_bbox": [-105.2385, 39.9027, -105.2115, 39.9155],
        "area_acres": 305,
        "published_capacity_statement": "More than 8 MW of installed wind, PV, and storage",
        "control_mode": "Read-only research demonstration",
    },
    "asset_counts": kind_counts,
    "geospatial_assets": assets,
    "roads": roads,
    "official_inventory": asset_master,
    "official_equipment_parameters": equipment,
    "facility_facts": facts,
    "current_observation": latest_observation,
    "observation_history": hourly_observations[-24:],
    "forecast": forecast_records,
    "capacity_scenario": {
        "observed_latest": observed_scenario,
        "wind_capacity_mw": observed_scenario["wind_capacity_mw"],
        "pv_capacity_mw": observed_scenario["pv_capacity_mw"],
        "parameters": scenario_parameters,
        "role": "site-capacity scenario; not device SCADA",
    },
    "nws_alerts": {
        "count": len(alerts.get("features", [])),
        "updated": alerts.get("updated"),
        "features": alerts.get("features", []),
    },
    "external_device_validation": {
        "site": "Open ten-turbine dataset from Greece",
        "role": "external algorithm validation; not Flatirons telemetry",
        "records": health,
    },
    "regenerative_state": {
        "method": "Evidence-Gated Regenerative Asset State (EGRAS)",
        "metrics": egras_metrics,
        "active_projection_count": len(egras_audit.get("active", [])),
        "recent_events": egras_audit.get("events", [])[-8:],
        "interfaces": ["identity", "validity", "source", "quality", "lineage", "allowed actions", "blocked claims"],
        "site_states": site_state.get("active", []),
        "site_history": site_state.get("history", []),
    },
    "extreme_wind_evaluation": warning_metrics,
    "external_wind_evaluation": external_metrics,
    "stress_test": {
        "lead_hours": [0, 3, 6, 9, 12],
        "wind_speed_80m_mps": [18.0, 23.5, 29.0, 26.5, 20.5],
        "role": "simulated extreme-wind workflow rehearsal",
        "device_action_allowed": False,
    },
    "data_roles": {
        "observed": "M2 meteorological measurement",
        "forecast": "NOAA GFS weather forecast",
        "model_derived": "transparent threshold or capacity-level calculation",
        "simulated": "workflow stress test without a claim about current conditions",
        "unavailable": "no public Flatirons device-level source",
    },
    "claim_boundaries": {
        "geometry": "OSM snapshot geometry is source-backed; it is not an owner-authorized asset register.",
        "identity": "Mapped wind and PV geometry is not uniquely bound to the official model and capacity inventory.",
        "telemetry": "Flatirons per-device SCADA, alarms, maintenance, and production are unavailable.",
        "animation": "Rotor speed is a site-weather-driven visual state, not measured rotor rpm.",
        "power": "Power is a capacity-level scenario using published aggregate capacity and proxy curves, not a plant settlement value.",
        "control": "Automatic control and device commands are disabled.",
    },
    "sources": {
        "SRC-001": "Official NLR Flatirons Campus facility page",
        "SRC-002": "NOAA GFS public forecast archive",
        "SRC-011": "Official Flatirons capability map",
        "SRC-024": "Official NLR wind facilities research page",
        "SRC-026": "NLR M2 MIDC meteorological observations",
        "SRC-031": "OpenStreetMap campus snapshot, ODbL 1.0",
        "IMG-001": "Esri World Imagery visual-context snapshot",
    },
    "source_metadata": {
        "osm": osm_manifest,
        "imagery": {
            "provider": "Esri World Imagery",
            "service_url": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer",
            "retrieved_on": "2026-10-19",
            "bbox_wgs84": [-105.2385, 39.9027, -105.2115, 39.9155],
            "copyright": "Source: Esri, Vantor, Earthstar Geographics, and the GIS User Community",
            "permitted_role": "visual site context only; not a scientific measurement layer",
        },
    },
}

input_manifest = {
    key: {
        "path": str(path.relative_to(PROJECT_DIR)) if PROJECT_DIR in path.parents else str(path.relative_to(DEMO_DIR)),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }
    for key, path in paths.items()
}
for key, path in {
    "egras_metrics": egras_metrics_path,
    "egras_audit": egras_audit_path,
    "extreme_wind_evaluation": warning_metrics_path,
    "external_wind_evaluation": external_metrics_path,
    "site_state": site_state_path,
}.items():
    if path.exists():
        input_manifest[key] = {
            "path": str(path.relative_to(DEMO_DIR)),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        }

(DEMO_DIR / "data.js").write_text(
    "window.TWIN_DATA = " + json.dumps(demo_data, ensure_ascii=False, separators=(",", ":")) + ";\n",
    encoding="utf-8",
)
(DEMO_DIR / "来源清单.json").write_text(
    json.dumps(
        {
            "generated_at_utc": demo_data["generated_at_utc"],
            "inputs": input_manifest,
            "claim_boundaries": demo_data["claim_boundaries"],
        },
        ensure_ascii=False,
        indent=2,
    ),
    encoding="utf-8",
)

print(f"DATA_JS_OK {DEMO_DIR / 'data.js'}")
print(f"ASSET_COUNTS {json.dumps(kind_counts, sort_keys=True)}")
print(f"FORECAST_RECORDS {len(forecast_records)}")
print(f"CURRENT_WIND_80M {latest_observation['wind_speed_80m_mps']}")

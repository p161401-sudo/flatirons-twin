import * as THREE from "./外部依赖 Vendor Dependencies/three.module.js";
import { OrbitControls } from "./外部依赖 Vendor Dependencies/OrbitControls.js";

const DATA = window.TWIN_DATA;
if (!DATA) throw new Error("TWIN_DATA is unavailable. Run 构建演示数据.py first.");

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const fmt = (value, digits = 1) => value === null || value === undefined || Number.isNaN(Number(value)) ? "--" : Number(value).toFixed(digits);
const esc = (value) => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"})[c]);

const translations = {
  brandSubtitle: ["3D site · hourly weather · maintenance records", "三维场址 · 逐时气象 · 巡检维修记录"],
  siteWind: ["Archived M2 80 m wind", "M2存档80米风速"], forecastHorizon: ["Archive lead", "历史预报时效"], weatherScreen: ["Archived weather screen", "历史天气筛查"],
  observed: ["Observed", "实测"], forecast: ["Forecast", "预报"], modelDerived: ["Model-derived", "模型计算"], simulated: ["Simulated", "模拟"], unavailable: ["Unavailable", "暂无数据"], readOnly: ["Read-only", "只读"],
  overview: ["Overview", "全场"], windAssets: ["Wind", "风机"], solarAssets: ["Solar", "光伏"], topView: ["Plan", "俯视"], plantModel: ["PLANT MODEL", "电厂模型"], siteName: ["Flatirons Campus", "Flatirons园区"],
  acres: ["acres", "英亩"], mappedTurbines: ["mapped turbines", "台地图风机"], mappedPv: ["mapped PV areas", "个光伏区"], metTowers: ["met towers", "座测风塔"],
  assets: ["Assets", "设备"], layers: ["Layers", "图层"], dataContext: ["Data context", "数据口径"], all: ["All", "全部"], weather: ["Weather", "气象"], sceneLayers: ["SCENE LAYERS", "场景图层"],
  windTurbines: ["Wind turbines", "风力机"], pvFields: ["PV fields", "光伏阵列"], buildings: ["Buildings", "建筑"], roads: ["Roads", "道路"], sceneLabels: ["Scene labels", "场景标签"],
  displayMode: ["DISPLAY MODE", "显示模式"], operatingContext: ["Operating context", "运行环境"], riskView: ["Extreme-wind view", "极端风风险"],
  observedDesc: ["M2 station measurements", "M2测风塔观测"], forecastDesc: ["NOAA GFS weather fields", "NOAA GFS天气预报"], modelDesc: ["Transparent screening and capacity scenarios", "透明阈值筛查与容量级情景"], simulatedDesc: ["Stress-test workflow", "压力测试流程"], unavailableDesc: ["No public device-level source", "没有公开设备级来源"],
  siteBoundaryShort: ["Geometry and official inventory are source-backed but are not uniquely bound device by device. Flatirons SCADA and maintenance records are not public.", "场址几何与官方设备清单均有来源，但公开资料未提供逐台对应关系。Flatirons设备级SCADA和维护记录未公开。"],
  operation: ["Operation", "运行"], risk: ["Alert", "预警"], stateTab: ["Data state", "数据状态"], maintenance: ["Maintenance", "维护"], evidence: ["Sources", "来源"],
  timeContext: ["TIME CONTEXT", "时间背景"], wind80m: ["80 m wind", "80米风速"], threeHourChange: ["3 h change", "3小时变化"], windScenario: ["Wind scenario", "风电情景"], stressTest: ["Stress test", "压力测试"], stressTestSub: ["Simulated extreme-wind rehearsal", "模拟极端风处置演练"],
  auditBoundary: ["DATA SCOPE AND CLAIM BOUNDARY", "数据范围与结论边界"], evidenceTitle: ["What this prototype can support", "本原型能够支持的结论"], sourceBackedGeometry: ["Source-backed geometry", "来源可追溯的场址几何"],
  sourceBackedGeometryDesc: ["Five turbine points, 13 PV polygons, four met towers, buildings, roads and the site boundary come from a fixed OSM snapshot.", "5个风机点、13个光伏面、4座测风塔、建筑、道路和场界来自固定的OSM快照。"],
  weatherEvidence: ["Weather evidence", "天气证据"], weatherEvidenceDesc: ["M2 supplies observations. GFS supplies the H0–H12 weather field. Risk is a transparent weather screen.", "M2提供实测，GFS提供H0至H12天气场，风险结果来自透明的天气阈值筛查。"],
  inventoryEvidence: ["Official facility inventory", "官方设备清单"], inventoryEvidenceDesc: ["Published model and capacity records are retained separately because public evidence does not bind them to each map point.", "已公开的机型和容量单独保存，因为公开证据没有给出它们与地图点位的逐台对应关系。"],
  blockedClaims: ["Blocked claims", "不可使用的主张"], blockedClaimsDesc: ["No Flatirons per-device SCADA, alarm, maintenance, availability, production or command data are asserted.", "不声称拥有Flatirons逐台SCADA、报警、维护、可利用率、发电量或控制指令数据。"], automaticControlOff: ["Automatic control disabled", "自动控制已关闭"],
  displayedItem: ["Displayed item", "显示内容"], dataRole: ["Data type", "资料类型"], interpretation: ["Permitted interpretation", "允许解释"], rotorAnimation: ["Rotor animation", "叶轮动画"], rotorBoundary: ["Rotor speed is a visual state driven by site wind", "叶轮转速为场址风速驱动的视觉状态"],
  capacityPower: ["Capacity-level power", "容量级功率"], powerBoundary: ["Weather-driven scenario, power at site-capacity level", "天气驱动情景，功率按场址容量口径"], extremeWorkflow: ["Extreme-wind workflow", "极端风流程"], workflowBoundary: ["Interface and response rehearsal; no current-event claim", "界面与响应流程演练，不声称当前事件正在发生"], deviceHealth: ["Flatirons device health", "Flatirons设备健康"], healthBoundary: ["No public device-level telemetry or confirmed failures", "没有公开设备级遥测或已确认故障"],
  findAsset: ["Find an asset", "查找设备"], mappedGeometry: ["Mapped geometry", "地图几何"], siteWeatherContext: ["Weather exposure", "天气暴露状态"], deviceScadaUnavailable: ["Device SCADA unavailable", "设备级SCADA未公开"],
  currentContext: ["Weather exposure", "天气暴露"], siteWideScenario: ["Site-wide scenario", "全场情景"], deviceUptime: ["Device uptime", "设备可利用率"], latestM2: ["Latest M2 observation", "M2最新观测"], noDeviceReading: ["No device reading", "没有设备读数"],
  siteWeatherHistory: ["M2 observation and GFS forecast", "M2观测与GFS预报"], publishedInventory: ["Published inventory, not point-bound", "已公开设备清单，未与点位绑定"],
  capacityBoundary: ["The displayed power is calculated for the published site-level capacity. It is not assigned to this map object.", "所示功率按公开的场址总容量计算，不分配给当前地图对象。"],
  normal: ["Normal", "正常"], advisory: ["Advisory", "关注"], critical: ["Critical", "严重"], archivedForecast: ["Archived GFS snapshot", "存档GFS快照"], simulatedStress: ["Simulated stress test", "模拟压力测试"],
  forecastScreening: ["Forecast screening", "预报筛查"], evidenceCheck: ["Source check", "来源核查"], assetReview: ["Asset review", "设备核查"], responseBoundary: ["Response boundary", "响应边界"],
  screenDesc: ["Compare forecast wind and three-hour change with transparent research thresholds.", "用透明的研究阈值检查预报风速和三小时变化。"], evidenceDesc: ["Confirm issue time, valid time, source continuity and M2 availability.", "核对起报时间、有效时间、来源连续性和M2观测可用性。"], assetReviewDesc: ["Check model-specific OEM limits before any device action; public point-to-model binding is unavailable.", "执行设备操作前必须核对相应机型的OEM限值；公开资料没有点位与机型的对应关系。"], responseDesc: ["The platform issues a research advisory only. Automatic commands remain disabled.", "平台仅给出科研提示，自动控制保持关闭。"],
  noMaintenance: ["No source-backed device maintenance history", "没有来源支持的设备维护历史"], noMaintenanceDesc: ["Public Flatirons sources do not provide per-device work orders, inspections, alarm logs, downtime or component replacement records.", "Flatirons公开来源不包含逐台工单、检查、报警、停机或部件更换记录。"],
  workflowRehearsal: ["Stress-test work-order rehearsal", "压力测试工单演练"], detect: ["Detect", "发现"], verify: ["Verify", "核验"], inspect: ["Inspect", "检查"], close: ["Close", "关闭"],
  detectDesc: ["Weather screen crosses the simulated threshold.", "天气筛查越过模拟阈值。"], verifyDesc: ["Operator verifies source status and OEM applicability.", "操作人员核验数据来源状态和OEM适用性。"], inspectDesc: ["A field inspection would require an authorized work order.", "现场检查必须基于经授权的工单。"], closeDesc: ["Closure requires device evidence that this public demonstrator does not possess.", "关闭工单需要本公开演示并不具备的设备证据。"],
  recordType: ["Record type", "记录类型"], value: ["Value", "值"], source: ["Source", "来源"], coordinate: ["Coordinate", "坐标"], osmObject: ["OSM object", "OSM对象"], identityBinding: ["Model binding", "机型绑定"], notUniquelyBound: ["Not uniquely bound", "未逐台对应"], telemetry: ["Telemetry", "遥测"], maintenanceRecord: ["Maintenance record", "维护记录"], control: ["Control", "控制"], disabled: ["Disabled", "已关闭"],
  officialInventoryNote: ["Official model and capacity entries remain separate from mapped points.", "官方机型和容量记录与地图点位分别保存。"],
};

const initialLanguage = (() => {
  try {
    const q = new URLSearchParams(location.search).get("lang");
    if (q === "en" || q === "zh") return q;
  } catch (error) {}
  return "zh";
})();

const state = {
  language: initialLanguage,
  selected: null,
  rightTab: "operation",
  leftTab: "assets",
  assetFilter: "all",
  horizonIndex: 0,
  stress: false,
  visualMode: "normal",
  labelsVisible: true,
  browseWeather: null,
};

const t = key => {
  const item = translations[key];
  if (!item) return key;
  return item[state.language === "en" ? 0 : 1];
};

const kindLabel = kind => ({
  wind_turbine: state.language === "en" ? "Wind turbine" : "风力机",
  pv_array: state.language === "en" ? "PV area" : "光伏区",
  met_tower: state.language === "en" ? "Meteorological tower" : "测风塔",
  facility_building: state.language === "en" ? "Facility building" : "场内建筑",
  substation: state.language === "en" ? "Substation" : "变电设施",
  grid_interface: state.language === "en" ? "Grid interface" : "电网接口",
  site_boundary: state.language === "en" ? "Site boundary" : "场址边界",
})[kind] || kind;

const shortName = feature => {
  const p = feature.properties;
  if (p.kind === "wind_turbine") return p.asset_id.replace("FLATIRONS_", "").replaceAll("_", "-");
  if (p.kind === "pv_array") return p.asset_id.replace("FLATIRONS_PV_GEOMETRY_", "PV-");
  if (p.kind === "met_tower") return p.asset_id.replace("FLATIRONS_MET_", "");
  if (p.kind === "substation") return state.language === "en" ? "115 kV substation" : "115 kV变电站";
  if (p.kind === "grid_interface") return "CGI";
  return p.name || p.asset_id;
};

const forecastAt = () => {
  const lead = DATA.stress_test.lead_hours[state.horizonIndex];
  const actual = DATA.forecast.find(row => row.lead_hours === lead) || DATA.forecast[0];
  if (!state.stress) return {...actual, stress: false};
  const wind = DATA.stress_test.wind_speed_80m_mps[state.horizonIndex];
  const previous = state.horizonIndex ? DATA.stress_test.wind_speed_80m_mps[state.horizonIndex - 1] : null;
  return {
    ...actual,
    wind_speed_80m_screen_mps: wind,
    three_hour_change_mps: previous === null ? null : wind - previous,
    wind_power_mw_scenario: wind >= 25 ? 0 : DATA.capacity_scenario.wind_capacity_mw,
    high_wind_weather_screen: wind >= 22,
    rapid_change_weather_screen: previous !== null && Math.abs(wind - previous) >= 4,
    stress: true,
  };
};

const riskLevel = record => {
  const wind = Number(record.wind_speed_80m_screen_mps || 0);
  if (record.stress && wind >= 25) return "critical";
  if (record.high_wind_weather_screen || record.rapid_change_weather_screen || (record.stress && wind >= 20)) return "advisory";
  return "normal";
};

let scene;
let camera;
let renderer;
let controls;
let clock;
let cameraMove = null;
let currentWind = DATA.current_observation.wind_speed_80m_mps;
let selectable = [];
let turbineRotors = [];
let objectById = new Map();
let labelRecords = [];
let selectedOutline = null;
let pointerDown = null;

const layerGroups = {};
const bbox = DATA.site.imagery_bbox;
const centerLon = (bbox[0] + bbox[2]) / 2;
const centerLat = (bbox[1] + bbox[3]) / 2;
const metersPerLon = 111320 * Math.cos(centerLat * Math.PI / 180);
const metersPerLat = 110540;
const sceneWidth = (bbox[2] - bbox[0]) * metersPerLon;
const sceneDepth = (bbox[3] - bbox[1]) * metersPerLat;

function toLocal(lon, lat) {
  return new THREE.Vector3((lon - centerLon) * metersPerLon, 0, -(lat - centerLat) * metersPerLat);
}

function featureCenter(feature) {
  const p = feature.properties || {};
  if (Number.isFinite(Number(p.center_lon)) && Number.isFinite(Number(p.center_lat))) return toLocal(Number(p.center_lon), Number(p.center_lat));
  const points = [];
  const walk = coords => {
    if (Array.isArray(coords) && coords.length >= 2 && typeof coords[0] === "number") points.push(coords);
    else if (Array.isArray(coords)) coords.forEach(walk);
  };
  walk(feature.geometry.coordinates);
  const lon = points.reduce((sum, point) => sum + point[0], 0) / points.length;
  const lat = points.reduce((sum, point) => sum + point[1], 0) / points.length;
  return toLocal(lon, lat);
}

function makeShape(feature) {
  const ring = feature.geometry.coordinates[0];
  const points = ring.map(([lon, lat]) => toLocal(lon, lat));
  const shape = new THREE.Shape();
  points.forEach((point, index) => index ? shape.lineTo(point.x, -point.z) : shape.moveTo(point.x, -point.z));
  shape.closePath();
  return {shape, points};
}

function bindAsset(object, feature) {
  object.userData.assetFeature = feature;
  object.traverse(child => child.userData.assetFeature = feature);
  selectable.push(object);
  objectById.set(feature.properties.asset_id, object);
}

function createTurbine(feature) {
  const group = new THREE.Group();
  const center = featureCenter(feature);
  group.position.copy(center);
  const towerMaterial = new THREE.MeshStandardMaterial({color: 0xe7eceb, metalness: 0.38, roughness: 0.46});
  const nacelleMaterial = new THREE.MeshStandardMaterial({color: 0xd9e0df, metalness: 0.42, roughness: 0.4});
  const bladeMaterial = new THREE.MeshStandardMaterial({color: 0xf3f6f5, metalness: 0.2, roughness: 0.48});
  const tower = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 2.8, 72, 18), towerMaterial);
  tower.position.y = 36;
  tower.castShadow = true;
  tower.receiveShadow = true;
  group.add(tower);
  const nacelle = new THREE.Mesh(new THREE.BoxGeometry(8, 4.2, 4.8), nacelleMaterial);
  nacelle.position.set(0, 73, 0.5);
  nacelle.castShadow = true;
  group.add(nacelle);
  const rotor = new THREE.Group();
  rotor.position.set(0, 73, 3.1);
  const hub = new THREE.Mesh(new THREE.SphereGeometry(2.2, 18, 12), nacelleMaterial);
  hub.castShadow = true;
  rotor.add(hub);
  for (let i = 0; i < 3; i += 1) {
    const bladePivot = new THREE.Group();
    bladePivot.rotation.z = i * Math.PI * 2 / 3;
    const blade = new THREE.Mesh(new THREE.BoxGeometry(1.15, 28, 0.55), bladeMaterial);
    blade.position.y = 14.8;
    blade.scale.x = 0.8;
    blade.castShadow = true;
    bladePivot.add(blade);
    rotor.add(bladePivot);
  }
  group.add(rotor);
  const ringMaterial = new THREE.MeshBasicMaterial({color: 0xe9c25f, transparent: true, opacity: 0.92, side: THREE.DoubleSide});
  const ring = new THREE.Mesh(new THREE.RingGeometry(10, 12, 48), ringMaterial);
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.75;
  ring.visible = false;
  group.add(ring);
  group.userData.selectionVisual = ring;
  group.userData.rotor = rotor;
  group.userData.baseScale = 1;
  turbineRotors.push(rotor);
  bindAsset(group, feature);
  layerGroups.wind.add(group);
  addSceneLabel(feature, new THREE.Vector3(center.x, 108, center.z));
}

function createPolygonAsset(feature, type) {
  const {shape} = makeShape(feature);
  const depth = type === "building" ? 8 + (Number(feature.properties.osm_id || 0) % 7) : 0.9;
  const geometry = new THREE.ExtrudeGeometry(shape, {depth, bevelEnabled: false, curveSegments: 1});
  geometry.rotateX(-Math.PI / 2);
  const material = type === "pv"
    ? new THREE.MeshStandardMaterial({color: 0x236b76, metalness: 0.38, roughness: 0.32, transparent: true, opacity: 0.46})
    : new THREE.MeshStandardMaterial({color: 0xc8d0cc, metalness: 0.12, roughness: 0.78, transparent: true, opacity: 0.92});
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.y = type === "pv" ? 1.1 : 0.3;
  mesh.castShadow = type === "building";
  mesh.receiveShadow = true;
  const edge = new THREE.LineSegments(new THREE.EdgesGeometry(geometry), new THREE.LineBasicMaterial({color: type === "pv" ? 0xa9d5da : 0x6e8183, transparent: true, opacity: 0.72}));
  edge.position.copy(mesh.position);
  const group = new THREE.Group();
  group.add(mesh, edge);
  const selectedEdge = new THREE.LineSegments(new THREE.EdgesGeometry(geometry), new THREE.LineBasicMaterial({color: 0xf0ca62, linewidth: 2}));
  selectedEdge.position.copy(mesh.position);
  selectedEdge.visible = false;
  group.add(selectedEdge);
  group.userData.selectionVisual = selectedEdge;
  bindAsset(group, feature);
  layerGroups[type === "pv" ? "pv" : "buildings"].add(group);
}

function createTower(feature) {
  const group = new THREE.Group();
  const center = featureCenter(feature);
  group.position.copy(center);
  const material = new THREE.MeshStandardMaterial({color: 0x58b7c7, metalness: 0.55, roughness: 0.42});
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.65, 46, 8), material);
  mast.position.y = 23;
  mast.castShadow = true;
  group.add(mast);
  for (const height of [15, 28, 40]) {
    const arm = new THREE.Mesh(new THREE.BoxGeometry(9, 0.4, 0.4), material);
    arm.position.y = height;
    group.add(arm);
  }
  const beacon = new THREE.Mesh(new THREE.SphereGeometry(1.2, 12, 8), new THREE.MeshBasicMaterial({color: 0x7dd1de}));
  beacon.position.y = 46.5;
  group.add(beacon);
  const ring = new THREE.Mesh(new THREE.RingGeometry(6, 7.5, 36), new THREE.MeshBasicMaterial({color: 0xe9c25f, side: THREE.DoubleSide}));
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.7;
  ring.visible = false;
  group.add(ring);
  group.userData.selectionVisual = ring;
  bindAsset(group, feature);
  layerGroups.met.add(group);
  if (feature.properties.asset_id === "FLATIRONS_MET_M2") addSceneLabel(feature, new THREE.Vector3(center.x, 62, center.z));
}

function createFacilityPoint(feature) {
  const group = new THREE.Group();
  const center = featureCenter(feature);
  group.position.copy(center);
  const base = new THREE.Mesh(new THREE.BoxGeometry(28, 10, 22), new THREE.MeshStandardMaterial({color: 0xc7b16f, metalness: 0.32, roughness: 0.58}));
  base.position.y = 5;
  base.castShadow = true;
  group.add(base);
  const bars = new THREE.Group();
  for (let i = -1; i <= 1; i += 1) {
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.6, 17, 8), new THREE.MeshStandardMaterial({color: 0x718286, metalness: 0.6, roughness: 0.35}));
    pole.position.set(i * 7, 13.5, 0);
    bars.add(pole);
  }
  group.add(bars);
  const ring = new THREE.Mesh(new THREE.RingGeometry(18, 20, 48), new THREE.MeshBasicMaterial({color: 0xe9c25f, side: THREE.DoubleSide}));
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.6;
  ring.visible = false;
  group.add(ring);
  group.userData.selectionVisual = ring;
  bindAsset(group, feature);
  layerGroups.buildings.add(group);
  addSceneLabel(feature, new THREE.Vector3(center.x, 34, center.z));
}

function createRoads() {
  const material = new THREE.LineBasicMaterial({color: 0xd6c790, transparent: true, opacity: 0.82});
  DATA.roads.features.forEach(feature => {
    const points = feature.geometry.coordinates.map(([lon, lat]) => {
      const point = toLocal(lon, lat);
      point.y = 1.0;
      return point;
    });
    if (points.length < 2) return;
    layerGroups.roads.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), material));
  });
}

function createBoundary(feature) {
  const ring = feature.geometry.coordinates[0].map(([lon, lat]) => {
    const point = toLocal(lon, lat);
    point.y = 1.5;
    return point;
  });
  layerGroups.roads.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(ring), new THREE.LineBasicMaterial({color: 0xe3bf63, transparent: true, opacity: 0.9})));
}

function createRiskField() {
  const group = layerGroups.risk;
  const turbineFeatures = DATA.geospatial_assets.features.filter(feature => feature.properties.kind === "wind_turbine");
  const direction = new THREE.Vector3(0.96, 0, 0.28).normalize();
  turbineFeatures.forEach((feature, index) => {
    const origin = featureCenter(feature).add(new THREE.Vector3(-115 - index * 7, 80 + index * 3, -30));
    const arrow = new THREE.ArrowHelper(direction, origin, 220, 0x5da9c0, 28, 12);
    arrow.userData.riskArrow = true;
    group.add(arrow);
    const ring = new THREE.Mesh(new THREE.RingGeometry(28, 36, 48), new THREE.MeshBasicMaterial({color: 0xb94c4b, transparent: true, opacity: 0.55, side: THREE.DoubleSide}));
    const center = featureCenter(feature);
    ring.position.set(center.x, 2.2, center.z);
    ring.rotation.x = -Math.PI / 2;
    group.add(ring);
  });
  group.visible = false;
}

function addSceneLabel(feature, position) {
  const element = document.createElement("button");
  element.type = "button";
  element.className = "scene-label";
  element.dataset.assetId = feature.properties.asset_id;
  element.innerHTML = `<i></i><b>${esc(shortName(feature))}</b>`;
  element.addEventListener("click", event => {
    event.stopPropagation();
    selectFeature(feature, true);
  });
  $("#sceneLabels").append(element);
  labelRecords.push({feature, position, element});
}

function initScene() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0xdbe7e6);
  scene.fog = new THREE.Fog(0xdbe7e6, 1800, 3900);
  camera = new THREE.PerspectiveCamera(44, innerWidth / innerHeight, 0.5, 7000);
  renderer = new THREE.WebGLRenderer({antialias: true, powerPreference: "high-performance"});
  renderer.domElement.id = "twinCanvas";
  renderer.setSize(innerWidth, innerHeight);
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.04;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  $("#sceneRoot").prepend(renderer.domElement);
  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.065;
  controls.minDistance = 130;
  controls.maxDistance = 3200;
  controls.maxPolarAngle = Math.PI / 2.08;
  controls.screenSpacePanning = false;
  clock = new THREE.Clock();

  const ambient = new THREE.HemisphereLight(0xeef8f8, 0x6f7666, 2.2);
  scene.add(ambient);
  const sun = new THREE.DirectionalLight(0xfff2cf, 3.2);
  sun.position.set(-600, 1200, 850);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -1400;
  sun.shadow.camera.right = 1400;
  sun.shadow.camera.top = 1100;
  sun.shadow.camera.bottom = -1100;
  sun.shadow.camera.far = 3500;
  scene.add(sun);

  ["wind", "pv", "buildings", "roads", "met", "risk"].forEach(name => {
    layerGroups[name] = new THREE.Group();
    layerGroups[name].name = name;
    scene.add(layerGroups[name]);
  });

  const texture = new THREE.TextureLoader().load("网站资源 Web Assets/flatirons_world_imagery.png", () => $("#sceneLoading").classList.add("hidden"));
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = renderer.capabilities.getMaxAnisotropy();
  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(sceneWidth, sceneDepth, 1, 1),
    new THREE.MeshStandardMaterial({map: texture, roughness: 0.92, metalness: 0.0})
  );
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  ground.name = "Satellite context plane";
  scene.add(ground);

  DATA.geospatial_assets.features.forEach(feature => {
    const kind = feature.properties.kind;
    if (kind === "wind_turbine") createTurbine(feature);
    else if (kind === "pv_array") createPolygonAsset(feature, "pv");
    else if (kind === "facility_building") createPolygonAsset(feature, "building");
    else if (kind === "met_tower") createTower(feature);
    else if (kind === "substation" || kind === "grid_interface") {
      if (feature.geometry.type === "Polygon") createPolygonAsset(feature, "building");
      else createFacilityPoint(feature);
    } else if (kind === "site_boundary") createBoundary(feature);
  });
  createRoads();
  createRiskField();
  setCamera("overview", false);

  renderer.domElement.addEventListener("pointerdown", event => pointerDown = {x: event.clientX, y: event.clientY});
  renderer.domElement.addEventListener("pointerup", handleSceneClick);
  addEventListener("resize", onResize);
  animate();
}

const cameraPresets = {
  overview: {position: new THREE.Vector3(930, 980, 1180), target: new THREE.Vector3(-60, 0, -20)},
  wind: {position: new THREE.Vector3(660, 650, 1060), target: new THREE.Vector3(-45, 38, 130)},
  solar: {position: new THREE.Vector3(-710, 430, 520), target: new THREE.Vector3(-420, 0, -80)},
  top: {position: new THREE.Vector3(0, 2250, 0.1), target: new THREE.Vector3(0, 0, 0)},
};

function setCamera(name, animated = true) {
  const preset = cameraPresets[name] || cameraPresets.overview;
  $$("[data-camera]").forEach(button => button.classList.toggle("active", button.dataset.camera === name));
  if (!animated) {
    camera.position.copy(preset.position);
    controls.target.copy(preset.target);
    controls.update();
    return;
  }
  cameraMove = {
    start: performance.now(), duration: 760,
    fromPosition: camera.position.clone(), toPosition: preset.position.clone(),
    fromTarget: controls.target.clone(), toTarget: preset.target.clone(),
  };
}

function focusAsset(feature) {
  const center = featureCenter(feature);
  const kind = feature.properties.kind;
  const height = kind === "wind_turbine" ? 72 : kind === "met_tower" ? 45 : 8;
  const offset = kind === "wind_turbine" ? new THREE.Vector3(150, 105, 185) : new THREE.Vector3(110, 95, 125);
  cameraMove = {
    start: performance.now(), duration: 620,
    fromPosition: camera.position.clone(), toPosition: center.clone().add(offset),
    fromTarget: controls.target.clone(), toTarget: center.clone().add(new THREE.Vector3(0, height * 0.38, 0)),
  };
}

function handleSceneClick(event) {
  if (!pointerDown || Math.hypot(event.clientX - pointerDown.x, event.clientY - pointerDown.y) > 5) return;
  const rect = renderer.domElement.getBoundingClientRect();
  const pointer = new THREE.Vector2(((event.clientX - rect.left) / rect.width) * 2 - 1, -((event.clientY - rect.top) / rect.height) * 2 + 1);
  const raycaster = new THREE.Raycaster();
  raycaster.setFromCamera(pointer, camera);
  const hit = raycaster.intersectObjects(selectable, true)[0];
  if (!hit) return;
  let object = hit.object;
  while (object && !object.userData.assetFeature) object = object.parent;
  if (object?.userData.assetFeature) selectFeature(object.userData.assetFeature, false);
}

function onResize() {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
  if (innerWidth <= 760) {
    $("#assetPanel").classList.remove("mobile-open");
    $("#inspectorPanel").classList.remove("mobile-open");
  }
  setTimeout(updateRuntimeAudit, 100);
}

function animate() {
  requestAnimationFrame(animate);
  const delta = Math.min(clock.getDelta(), 0.05);
  const rotorRate = state.browseWeather ? 0 : 0.08 + clamp(currentWind, 0, 32) * 0.038;
  turbineRotors.forEach((rotor, index) => rotor.rotation.z -= delta * rotorRate * (0.92 + index * 0.025));
  if (cameraMove) {
    const progress = clamp((performance.now() - cameraMove.start) / cameraMove.duration, 0, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    camera.position.lerpVectors(cameraMove.fromPosition, cameraMove.toPosition, eased);
    controls.target.lerpVectors(cameraMove.fromTarget, cameraMove.toTarget, eased);
    if (progress >= 1) cameraMove = null;
  }
  controls.update();
  updateSceneLabels();
  renderer.render(scene, camera);
}

function updateSceneLabels() {
  const width = renderer.domElement.clientWidth;
  const height = renderer.domElement.clientHeight;
  const cameraDirection = new THREE.Vector3();
  camera.getWorldDirection(cameraDirection);
  labelRecords.forEach(record => {
    const projected = record.position.clone().project(camera);
    const viewVector = record.position.clone().sub(camera.position).normalize();
    const behind = cameraDirection.dot(viewVector) < 0;
    const x = (projected.x * 0.5 + 0.5) * width;
    const y = (-projected.y * 0.5 + 0.5) * height;
    const visible = state.labelsVisible && !behind && projected.z > -1 && projected.z < 1 && x > 0 && x < width && y > 0 && y < height;
    record.element.style.display = visible ? "flex" : "none";
    if (visible) record.element.style.transform = `translate(-50%, -100%) translate(${x}px, ${y}px)`;
  });
}

function iconName(kind) {
  return ({wind_turbine: "wind", pv_array: "sun", met_tower: "radio-tower", substation: "zap", grid_interface: "plug-zap", facility_building: "building-2"})[kind] || "map-pin";
}

function iconClass(kind) {
  if (kind === "pv_array") return "solar";
  if (kind === "met_tower") return "weather";
  if (["facility_building", "substation", "grid_interface"].includes(kind)) return "facility";
  return "";
}

function renderAssetList() {
  const query = $("#assetSearch").value.trim().toLowerCase();
  const features = DATA.geospatial_assets.features.filter(feature => feature.properties.kind !== "site_boundary");
  const groups = [
    ["wind_turbine", state.language === "en" ? "WIND ASSETS" : "风力设备"],
    ["pv_array", state.language === "en" ? "PV AREAS" : "光伏区域"],
    ["met_tower", state.language === "en" ? "WEATHER SENSORS" : "气象设备"],
    ["facility", state.language === "en" ? "GRID AND FACILITIES" : "电网与建筑"],
  ];
  let html = "";
  groups.forEach(([groupKind, title]) => {
    const items = features.filter(feature => {
      const kind = feature.properties.kind;
      const groupMatch = groupKind === "facility" ? ["facility_building", "substation", "grid_interface"].includes(kind) : kind === groupKind;
      const filterMatch = state.assetFilter === "all" || state.assetFilter === kind;
      const text = `${shortName(feature)} ${feature.properties.name} ${feature.properties.asset_id}`.toLowerCase();
      return groupMatch && filterMatch && (!query || text.includes(query));
    });
    if (!items.length) return;
    html += `<div class="asset-group-title">${esc(title)} · ${items.length}</div>`;
    html += items.map(feature => {
      const p = feature.properties;
      const active = state.selected?.properties.asset_id === p.asset_id;
      const status = p.kind === "met_tower" && p.asset_id === "FLATIRONS_MET_M2" ? t("observed") : t("mappedGeometry");
      return `<button class="asset-row ${active ? "active" : ""}" type="button" data-asset-id="${esc(p.asset_id)}">
        <i class="asset-icon ${iconClass(p.kind)}"><i data-lucide="${iconName(p.kind)}"></i></i>
        <span><strong>${esc(shortName(feature))}</strong><small>${esc(kindLabel(p.kind))} · ${esc(status)}</small></span>
        <em>${p.kind === "met_tower" && p.asset_id === "FLATIRONS_MET_M2" ? "M2" : "OSM"}</em>
      </button>`;
    }).join("");
  });
  $("#assetList").innerHTML = html || `<p class="plain-alert">${state.language === "en" ? "No asset matches this filter." : "没有符合筛选条件的设备。"}</p>`;
  $$("[data-asset-id]", $("#assetList")).forEach(button => button.addEventListener("click", () => {
    const feature = features.find(item => item.properties.asset_id === button.dataset.assetId);
    if (feature) selectFeature(feature, true);
  }));
  window.lucide?.createIcons();
}

function selectFeature(feature, focus = false) {
  if (!feature) return;
  if (selectedOutline) selectedOutline.visible = false;
  state.selected = feature;
  window.dispatchEvent(new CustomEvent("twin-asset-selected", {detail: {asset_id: feature.properties.asset_id}}));
  const object = objectById.get(feature.properties.asset_id);
  selectedOutline = object?.userData.selectionVisual || null;
  if (selectedOutline) selectedOutline.visible = true;
  labelRecords.forEach(record => record.element.classList.toggle("selected", record.feature.properties.asset_id === feature.properties.asset_id));
  renderAssetList();
  renderInspector();
  if (focus) focusAsset(feature);
  if (innerWidth <= 760) {
    if (focus) {
      $("#assetPanel").classList.remove("mobile-open");
      $("#inspectorPanel").classList.add("mobile-open");
    }
  } else {
    $("#inspectorPanel").classList.remove("collapsed");
  }
}

function operationHtml(feature) {
  const p = feature.properties;
  const record = forecastAt();
  const wind = record.wind_speed_80m_screen_mps;
  const isM2 = p.asset_id === "FLATIRONS_MET_M2";
  const isPv = p.kind === "pv_array";
  const power = isPv
    ? (state.horizonIndex === 0 && !state.stress ? DATA.capacity_scenario.observed_latest.pv_power_mw_scenario : null)
    : record.wind_power_mw_scenario;
  const metricLabel = isPv ? (state.language === "en" ? "PV scenario" : "光伏情景") : (state.language === "en" ? "Wind scenario" : "风电情景");
  const metricValue = power === null || power === undefined ? (state.language === "en" ? "Observed context" : "观测背景") : `${fmt(power, 3)} MW`;
  const contextLabel = isPv ? (state.language === "en" ? "Latest M2 GHI" : "M2最新总辐照度") : isM2 ? t("latestM2") : t("currentContext");
  const contextValue = isPv ? `${fmt(DATA.current_observation.ghi_physical_wm2, 0)} W/m²` : isM2 ? `${fmt(DATA.current_observation.wind_speed_80m_mps, 2)} m/s` : `${fmt(wind, 2)} m/s`;
  const contextNote = isPv ? (state.language === "en" ? "Observed · nighttime floor" : "实测 · 夜间归零") : isM2 ? `${t("observed")} · SRC-026` : record.stress ? t("simulatedStress") : t("archivedForecast");
  const inventory = DATA.official_inventory.filter(row => row.asset_type === (p.kind === "pv_array" ? "pv_array" : "wind_turbine") && row.capacity_mw !== null);
  return `
    <div class="metric-band">
      <div><span>${esc(contextLabel)}</span><b>${esc(contextValue)}</b><small>${esc(contextNote)}</small></div>
      <div><span>${esc(metricLabel)}</span><b>${esc(metricValue)}</b><small>${esc(t("siteWideScenario"))}</small></div>
      <div><span>${state.language === "en" ? "Evidence snapshot" : "证据快照"}</span><b>SHA-256</b><small>${state.language === "en" ? "Versioned · traceable" : "版本化 · 可追溯"}</small></div>
    </div>
    <section class="content-section">
      <h3>${esc(isPv ? (state.language === "en" ? "M2 solar irradiance history" : "M2太阳辐照度历史") : t("siteWeatherHistory"))}</h3>
      ${isPv ? solarChartSvg() : weatherChartSvg()}
    </section>
    <section class="content-section">
      <h3>${esc(state.language === "en" ? "Asset record" : "设备记录")}</h3>
      <dl class="field-list">
        <div><dt>${esc(t("recordType"))}</dt><dd>${esc(kindLabel(p.kind))}</dd></div>
        <div><dt>${esc(t("coordinate"))}</dt><dd>${Number(p.center_lat).toFixed(6)}, ${Number(p.center_lon).toFixed(6)}</dd></div>
        <div><dt>${state.language === "en" ? "Exposure source" : "暴露度来源"}</dt><dd>${isM2 ? "M2 / SRC-026" : "GFS / site weather"}</dd></div>
        <div><dt>${esc(t("identityBinding"))}</dt><dd>${esc(t("notUniquelyBound"))}</dd></div>
      </dl>
    </section>
    ${["wind_turbine", "pv_array"].includes(p.kind) ? `<section class="content-section"><h3>${esc(t("publishedInventory"))}</h3><p>${inventory.map(row => `${esc(row.asset_name)}${row.capacity_mw ? ` · ${fmt(row.capacity_mw, 2)} MW` : ""}`).join("<br>") || esc(t("unavailable"))}</p><div class="plain-alert gold" style="margin-top:9px">${esc(t("capacityBoundary"))}</div></section>` : ""}
  `;
}

function solarChartSvg() {
  const values = DATA.observation_history.map(row => Math.max(0, Number(row.ghi_wm2))).filter(Number.isFinite);
  const width = 330, height = 104, padX = 8, padY = 12;
  const maxValue = Math.max(200, ...values) * 1.08;
  const path = values.map((value, index) => {
    const x = padX + (values.length === 1 ? 0 : index / (values.length - 1)) * (width - padX * 2);
    const y = height - padY - value / maxValue * (height - padY * 2);
    return `${index ? "L" : "M"}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  return `<svg class="mini-chart" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" aria-label="M2 observed solar irradiance">
    <line class="grid" x1="0" x2="${width}" y1="${height-padY}" y2="${height-padY}"></line>
    <line class="grid" x1="0" x2="${width}" y1="${height/2}" y2="${height/2}"></line>
    <path class="observed-line" d="${path}" style="stroke:#cba34c"></path>
    <text x="8" y="11">${state.language === "en" ? "M2 observed GHI" : "M2实测总辐照度"}</text>
    <text x="274" y="11">${maxValue.toFixed(0)} W/m²</text>
  </svg>`;
}

function weatherChartSvg() {
  const observed = DATA.observation_history.map(row => Number(row.wind_speed_80m_mps)).filter(Number.isFinite);
  const forecast = state.stress ? DATA.stress_test.wind_speed_80m_mps.map(Number) : DATA.forecast.map(row => Number(row.wind_speed_80m_screen_mps));
  const values = [...observed, ...forecast];
  const maxValue = Math.max(8, ...values) * 1.08;
  const width = 330, height = 104, padX = 8, padY = 12, mid = 232;
  const line = (series, x0, x1) => series.map((value, index) => {
    const x = x0 + (series.length === 1 ? 0 : index / (series.length - 1)) * (x1 - x0);
    const y = height - padY - value / maxValue * (height - padY * 2);
    return `${index ? "L" : "M"}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  return `<svg class="mini-chart" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" aria-label="M2 observed and GFS forecast wind speed">
    <line class="grid" x1="0" x2="${width}" y1="${height/2}" y2="${height/2}"></line>
    <line class="grid" x1="${mid}" x2="${mid}" y1="0" y2="${height}"></line>
    <path class="observed-line" d="${line(observed, padX, mid)}"></path>
    <path class="forecast-line" d="${line(forecast, mid, width-padX)}"></path>
    <text x="8" y="11">${state.language === "en" ? "M2 observed" : "M2实测"}</text>
    <text x="238" y="11">${state.stress ? esc(t("simulated")) : "GFS"}</text>
    <text x="300" y="${height-5}">${maxValue.toFixed(0)} m/s</text>
  </svg>`;
}

function riskHtml() {
  const record = forecastAt();
  const level = riskLevel(record);
  const levelText = t(level);
  const summary = level === "normal"
    ? (state.language === "en" ? "No high-wind or rapid-change flag in this archived forecast row." : "该存档预报时次未触发强风或快速变化标记。")
    : level === "critical"
      ? (state.language === "en" ? "The simulated wind exceeds the proxy cut-out value used only for workflow testing." : "模拟风速超过流程测试的代理切出值。")
      : (state.language === "en" ? "The weather screen requires operator review; it is not a device trip command." : "天气筛查提示需要人工复核。")
  return `
    <div class="risk-banner ${level === "normal" ? "" : level === "critical" ? "critical" : "warning"}">
      <div class="risk-level">${level === "normal" ? "L0" : level === "critical" ? "L3" : "L1"}</div>
      <div><b>${esc(levelText)} · ${fmt(record.wind_speed_80m_screen_mps, 2)} m/s</b><p>${esc(summary)}</p></div>
    </div>
    <section class="content-section">
      <h3>${state.language === "en" ? "Screen inputs" : "筛查输入"}</h3>
      <dl class="field-list">
        <div><dt>${state.language === "en" ? "Valid time" : "有效时间"}</dt><dd>${esc(record.valid_time_utc)}</dd></div>
        <div><dt>${state.language === "en" ? "3 h change" : "3小时变化"}</dt><dd>${record.three_hour_change_mps === null ? "--" : `${fmt(record.three_hour_change_mps, 2)} m/s`}</dd></div>
        <div><dt>${state.language === "en" ? "High-wind flag" : "强风标记"}</dt><dd>${record.high_wind_weather_screen ? (state.language === "en" ? "Triggered" : "已触发") : (state.language === "en" ? "Not triggered" : "未触发")}</dd></div>
        <div><dt>${state.language === "en" ? "Rapid-change flag" : "快速变化标记"}</dt><dd>${record.rapid_change_weather_screen ? (state.language === "en" ? "Triggered" : "已触发") : (state.language === "en" ? "Not triggered" : "未触发")}</dd></div>
      </dl>
    </section>
    <section class="content-section">
      <h3>${state.language === "en" ? "Extreme-wind decision path" : "极端风决策路径"}</h3>
      <div class="workflow-list">
        ${workflowStep(1, t("forecastScreening"), t("screenDesc"), record.stress ? t("simulated") : t("modelDerived"), record.stress ? "simulated" : "model")}
        ${workflowStep(2, t("evidenceCheck"), t("evidenceDesc"), t("forecast"), "forecast")}
        ${workflowStep(3, t("assetReview"), t("assetReviewDesc"), state.language === "en" ? "Review" : "人工复核", "model")}
        ${workflowStep(4, t("responseBoundary"), t("responseDesc"), t("readOnly"), "unavailable")}
      </div>
    </section>
    ${externalWarningEvidenceHtml()}
    ${warningEvidenceHtml()}
  `;
}

function warningEvidenceHtml() {
  const report = DATA.extreme_wind_evaluation;
  const zh = state.language === "zh";
  if (!report) return `<section class="content-section"><h3>${zh ? "历史预警验证" : "Historical warning evaluation"}</h3><p>${zh ? "历史档案采集与验证尚未完成；当前上方为透明阈值筛查，不展示未经计算的准确率。" : "Archive evaluation is pending; the screen above is a transparent rule, not a validated probability forecast."}</p></section>`;
  return `<section class="content-section"><h3>${zh ? "2025年回顾性高风评估" : "2025 retrospective high-wind evaluation"}</h3><p>${zh ? "统计高风阈值" : "Statistical high-wind threshold"}: ${fmt(report.threshold_mps, 2)} m/s · ${report.sample_counts.test} ${zh ? "测试样本" : "test samples"}</p><dl class="field-list">${report.metrics.map(row => `<div><dt>${esc(row.method)}</dt><dd>CSI ${fmt(row.csi, 3)} · R ${fmt(row.recall, 3)} · FAR ${fmt(row.false_alarm_ratio, 3)}</dd></div>`).join("")}</dl><p>${zh ? "历史统计高风验证与 25 m/s 工程演练分开列出，便于对照。" : "Historical statistical high winds are distinct from the 25 m/s rehearsal; no live automatic control."}</p><a href="论文素材 Paper Materials/图表与空间证据 Figures and Spatial Evidence/figures/Fig03 event forecast.png" target="_blank" rel="noopener">${zh ? "查看预报—实测事件图" : "Open observed–forecast event figure"}</a></section>`;
}

function externalWarningEvidenceHtml() {
  const report = DATA.external_wind_evaluation;
  if (!report) return "";
  const zh = state.language === "zh";
  const primary = report.metrics.find(row => row.method === report.primary_method);
  const baseline = report.metrics.find(row => row.method === "GFS-logistic");
  const raw = report.wind_metrics.find(row => row.method === "Raw-GFS");
  const corrected = report.wind_metrics.find(row => row.method === "Residual-corrected");
  const status = report.alert_improvement_confirmed
    ? (zh ? "达到本研究冻结报警改进判据，仍非现场极端预警认证。" : "Meets the frozen study criterion; not field extreme-warning certification.")
    : (zh ? "报警未达到冻结改进判据。" : "Does not meet the frozen alert-improvement criterion; not a mature extreme-warning system.");
  return `<section class="content-section"><h3>${zh ? "2026 Q1新时段验证" : "2026 Q1 temporal holdout"}</h3><p>${report.test_rows} ${zh ? "配对" : "pairs"} · ${report.test_issue_days} ${zh ? "起报日" : "issue days"} · ${report.events} ${zh ? "高风端点" : "high-wind endpoints"}</p><dl class="field-list"><div><dt>${zh ? "风速MAE" : "Wind MAE"}</dt><dd>${fmt(raw.mae_mps, 3)} → ${fmt(corrected.mae_mps, 3)} m/s</dd></div><div><dt>${esc(report.primary_method)}</dt><dd>CSI ${fmt(primary.csi, 3)} · R ${fmt(primary.recall, 3)} · FAR ${fmt(primary.false_alarm_ratio, 3)}</dd></div><div><dt>${zh ? "校准GFS强基线" : "Calibrated GFS baseline"}</dt><dd>CSI ${fmt(baseline.csi, 3)} · Brier ${fmt(baseline.brier, 3)}</dd></div></dl><p>${esc(status)}</p><p>${zh ? "2025年选型冻结后新获取的回顾性时间留出；不等于前瞻或跨场址验证。" : "Newly acquired retrospective holdout after 2025 model-selection freeze; not prospective or independent-site validation."}</p><a href="论文素材 Paper Materials/图表与空间证据 Figures and Spatial Evidence/figures/Fig07 external 2026 strongest event.png" target="_blank" rel="noopener">${zh ? "查看新时段实测事件图" : "Open new-period event figure"}</a></section>`;
}

function workflowStep(index, title, description, roleText, roleClass) {
  return `<div class="workflow-step"><i>${index}</i><div><b>${esc(title)}</b><p>${esc(description)}</p></div><em class="role role-${roleClass}">${esc(roleText)}</em></div>`;
}

function maintenanceHtml() {
  const zh = state.language === "zh";
  const record = forecastAt();
  const level = riskLevel(record);
  return `<section class="content-section"><h3>${zh ? "预警驱动的检查准备" : "Warning-driven inspection preparation"}</h3><div class="plain-alert gold">${zh ? "人工复核清单：核对时间与来源、现场复核、留存证据。" : "Human-review checklist; no invented work orders or shutdown commands."}</div><dl class="field-list"><div><dt>${zh ? "天气等级" : "Weather level"}</dt><dd>${esc(t(level))}</dd></div><div><dt>${zh ? "天气背景" : "Weather context"}</dt><dd>${fmt(record.wind_speed_80m_screen_mps, 2)} m/s</dd></div></dl><div class="workflow-list">${workflowStep(1, zh ? "核对起报与有效时间" : "Check issue and valid times", zh ? "核查气象来源、阈值和证据版本。" : "Verify weather source, threshold and evidence version.", "Review", "model")}${workflowStep(2, zh ? "现场人员复核" : "Operator review", level === "normal" ? (zh ? "保留日常巡检计划。" : "Retain routine inspection planning.") : (zh ? "结合现场规程评估户外作业、构件与光伏支架检查。" : "Review outdoor access, structures and PV support inspections under the site procedure."), "Review", "model")}${workflowStep(3, zh ? "留存证据并复查" : "Retain evidence and reassess", zh ? "记录预警、来源与复核意见；新预报到达后重新核对。" : "Retain alert provenance and review notes; reassess on the next forecast.", "Read-only", "model")}</div></section>`;
}

function evidenceHtml(feature) {
  const p = feature.properties;
  return `
    <section class="content-section">
      <h3>${state.language === "en" ? "Selected-object provenance" : "所选对象来源"}</h3>
      <dl class="field-list">
        <div><dt>${esc(t("source"))}</dt><dd>${esc(p.source_id || "SRC-031")}</dd></div>
        <div><dt>${esc(t("osmObject"))}</dt><dd>${esc(`${p.osm_type || "object"} ${p.osm_id || "--"}`)}</dd></div>
        <div><dt>${esc(t("coordinate"))}</dt><dd>${Number(p.center_lat).toFixed(7)}, ${Number(p.center_lon).toFixed(7)}</dd></div>
        <div><dt>${esc(t("identityBinding"))}</dt><dd>${esc(t("notUniquelyBound"))}</dd></div>
        <div><dt>${esc(t("telemetry"))}</dt><dd>${p.asset_id === "FLATIRONS_MET_M2" ? "M2 / SRC-026" : esc(t("unavailable"))}</dd></div>
        <div><dt>${esc(t("maintenanceRecord"))}</dt><dd>${esc(t("unavailable"))}</dd></div>
        <div><dt>${esc(t("control"))}</dt><dd>${esc(t("disabled"))}</dd></div>
      </dl>
    </section>
    <section class="content-section">
      <h3>${state.language === "en" ? "Evidence statement" : "证据说明"}</h3>
      <div class="source-row"><b>SRC-031</b><p>${esc(p.evidence_note || DATA.claim_boundaries.geometry)}</p></div>
      <div class="source-row"><b>SRC-011</b><p>${esc(t("officialInventoryNote"))}</p></div>
      <div class="source-row"><b>SHA-256</b><p>${esc(DATA.source_metadata.osm.sha256)}</p></div>
      <div class="source-row"><b>Snapshot</b><p>${esc(DATA.source_metadata.osm.retrieval_time_utc)}</p></div>
    </section>
  `;
}

function stateHtml(feature) {
  const zh = state.language === "zh";
  const engine = DATA.regenerative_state || {};
  const history = (engine.site_history || []).filter(row => row.asset_id === feature.properties.asset_id && row.projection === "weather_exposure");
  const lead = DATA.stress_test.lead_hours[state.horizonIndex];
  const selected = history.find(row => Number(row.payload.forecast_hour) === lead) || history.at(-1);
  const metrics = engine.metrics || {};
  return `<section class="content-section"><h3>EGRAS · ${zh ? "证据约束再生状态" : "Evidence-gated regenerative state"}</h3><p>${zh ? "先保留资产身份内核，再随证据分化与重建视图；生物比喻不是有效性证据。" : "Preserve identity and regenerate projections as evidence changes; the biological analogy is not validation."}</p>${selected ? `<dl class="field-list"><div><dt>${zh ? "状态版本" : "State version"}</dt><dd>v${selected.version} · ${esc(selected.status)}</dd></div><div><dt>${zh ? "有效时间" : "Valid time"}</dt><dd>${esc(selected.valid_from)}</dd></div><div><dt>${zh ? "来源角色" : "Evidence role"}</dt><dd>${esc(selected.data_role)}</dd></div><div><dt>SHA-256</dt><dd title="${esc(selected.source_hashes[0])}">${esc(selected.source_hashes[0].slice(0, 20))}…</dd></div><div><dt>${zh ? "父版本" : "Parent version"}</dt><dd>${selected.parent_state_ids.length ? `v${selected.version - 1}` : (zh ? "初始" : "Initial")}</dd></div></dl><p>${zh ? "这是来源快照的归档状态，可用于核对任何一次查询的出处。" : "Actual-source archived state, not live device telemetry. Stress tests do not overwrite archival evidence."}</p>` : ""}</section><section class="content-section"><h3>${zh ? "缺源—失效—再生实验" : "Missing-source regeneration experiment"}</h3><p>${zh ? "以下为合成依赖工作负载，用于检验增量重建的一致性。" : "Synthetic dependency workload, not field operational performance."}</p><dl class="field-list"><div><dt>${zh ? "证据更新次数" : "Evidence updates"}</dt><dd>${metrics.update_count || 0}</dd></div><div><dt>${zh ? "重建节点比例" : "Rebuilt node fraction"}</dt><dd>${fmt((metrics.mean_selective_recompute_fraction || 0) * 100, 1)}%</dd></div><div><dt>${zh ? "撤销 / 恢复" : "Deactivated / recovered"}</dt><dd>${metrics.deactivated_projection_count || 0} / ${metrics.recovered_projection_count || 0}</dd></div><div><dt>${zh ? "来源恢复角色正确" : "Restored evidence roles valid"}</dt><dd>${metrics.restored_roles_valid === true ? "PASS" : "PENDING"}</dd></div></dl></section>`;
}

function renderInspector() {
  const feature = state.selected;
  if (!feature) return;
  const p = feature.properties;
  $("#assetKind").textContent = `${kindLabel(p.kind).toUpperCase()} · ${t("mappedGeometry").toUpperCase()}`;
  $("#assetName").textContent = shortName(feature);
  $("#assetCoordinate").textContent = `${Number(p.center_lat).toFixed(6)}, ${Number(p.center_lon).toFixed(6)}`;
  if (state.browseWeather) {
    const context = state.browseWeather;
    const row = context.row;
    const zh = state.language === 'zh';
    if (context.research) {
      const value = row ? `${fmt(row.wind_mps, 3)} m/s` : '—';
      $("#assetState").textContent = zh ? '研究预报按对象回放' : 'Object-linked research replay';
      $("#assetStateNote").textContent = `${context.selected_time.slice(0, 16).replace('T', ' ')} UTC · ${value}`;
      $("#assetRole").className = 'role role-model';
      $("#assetRole").textContent = row ? (zh ? '模式预报回放' : 'Forecast replay') : t('unavailable');
      const fields = [
        [zh ? '有效时间 UTC' : 'Valid time UTC', row?.valid_time || '—'],
        [zh ? '起报时间 UTC' : 'Issue time UTC', row?.issue_time || '—'],
        [zh ? '预报时效' : 'Forecast lead', row ? `H${row.lead_hours}` : '—'],
        [zh ? '资料类型' : 'Data role', row ? (context.mode === 'corrected' ? (zh ? 'GFS残差订正归档' : 'GFS residual-corrected archive') : (zh ? 'GFS原始预报归档' : 'Raw GFS forecast archive')) : '—'],
        [zh ? 'M2目标高度' : 'M2 target height', row ? '80 m' : '—'],
        [zh ? '风速' : 'Wind speed', value],
        [zh ? '测站高风速事件概率' : 'Station high-wind event probability', row?.station_event_probability == null ? '—' : fmt(row.station_event_probability, 4)],
        [zh ? '测站统计筛查' : 'Station statistical screen', row ? (row.station_event_screen ? (zh ? '触发' : 'Flagged') : (zh ? '未触发' : 'Not flagged')) : '—'],
        [zh ? '设备风险评价' : 'Equipment risk assessment', zh ? '待提供设备限值与现场暴露数据' : 'Asset limits and local exposure data required']
      ];
      $("#inspectorContent").innerHTML = `<section class="content-section"><h3>${zh ? '归档预报与订正结果' : 'Archived forecasts and corrected values'}</h3><p>${esc(context.note)}</p><dl class="field-list">${fields.map(([label, field]) => `<div><dt>${esc(label)}</dt><dd>${esc(field)}</dd></div>`).join('')}</dl><p>${zh ? '11.059 m/s为训练样本统计分位数；筛查结果对应M2测站目标，设备位置保留各自坐标。' : 'The 11.059 m/s threshold is a training-sample percentile. Screening targets M2 while each object retains its own coordinates.'}</p><details><summary>${zh ? '来源校验值' : 'Source checksum'}</summary><p style="overflow-wrap:anywhere">${esc(context.source_hash || '—')}</p></details><p class="source-link"><a href="https://nomads.ncep.noaa.gov/pub/data/nccf/com/gfs/prod/" target="_blank" rel="noopener">GFS 报文存档（NOMADS）</a></p><button id="selectedHourRecord" type="button">${zh ? '记录检查事项' : 'Record an inspection item'}</button></section>`;
      $("#selectedHourRecord").addEventListener('click', () => window.dispatchEvent(new CustomEvent('open-manual-records', {detail: {selected_time: context.selected_time}})));
      return;
    }
    const wind = row ? context.forecast ? `${fmt(row.wind_low_mps, 2)}–${fmt(row.wind_high_mps, 2)}` : fmt(row.wind_mps, 2) : '—';
    $("#assetState").textContent = zh ? '所选时段气象关联' : 'Weather associated with selected hour';
    $("#assetStateNote").textContent = `${context.selected_time.slice(0, 16).replace('T', ' ')} UTC · ${wind}${row ? ' m/s' : ''}`;
    $("#assetRole").className = `role ${context.forecast ? 'role-forecast' : 'role-observed'}`;
    $("#assetRole").textContent = row ? context.forecast ? t('forecast') : t('observed') : t('unavailable');
    $("#inspectorContent").innerHTML = `<section class="content-section"><h3>${zh ? '按日期与小时查看气象' : 'Weather by date and hour'}</h3><p>${esc(context.note)}</p><dl class="field-list"><div><dt>${zh ? '所选小时 UTC' : 'Selected hour UTC'}</dt><dd>${esc(context.selected_time)}</dd></div><div><dt>${zh ? '资料有效时间' : 'Data valid time'}</dt><dd>${esc(row ? row.valid_from || row.observed_at : (zh ? '该小时无记录' : 'No record in this hour'))}</dd></div><div><dt>${zh ? '资料类型' : 'Data type'}</dt><dd>${esc(context.forecast ? 'NWS forecast' : context.mode + ' observation')}</dd></div><div><dt>${zh ? '风速 m/s' : 'Wind m/s'}</dt><dd>${esc(wind)}</dd></div><div><dt>${zh ? '高度 m' : 'Height m'}</dt><dd>${row?.height_m === null || row?.height_m === undefined ? (zh ? '来源未提供' : 'Not provided') : esc(row.height_m)}</dd></div><div><dt>${zh ? '温度 °C' : 'Temperature °C'}</dt><dd>${fmt(row?.temperature_c, 2)}</dd></div><div><dt>${zh ? '预报来源更新时间' : 'Forecast source updated'}</dt><dd>${esc(context.forecast ? context.source_time || '—' : '—')}</dd></div></dl><p>${row ? esc(zh ? '气象值按对象与时刻关联；设备遥测接入后可直接对照。' : 'Weather is associated with the selected mapped object, not measured on that device. Actual power, faults and rotor RPM are unavailable.') : esc(zh ? '未使用其他日期或测站的数值填补本小时。' : 'No value from another date or station fills this hour.')}</p>${context.stale ? `<p class="operations-warning">${zh ? '来源请求失败或资料已过期，仅供回看。' : 'Source fetch failed or data are stale; replay only.'}</p>` : ''}<details><summary>${zh ? '来源校验值' : 'Source checksum'}</summary><p style="overflow-wrap:anywhere">SHA-256 ${esc(context.source_hash || '—')}</p></details><p class="source-link"><a href="https://nomads.ncep.noaa.gov/pub/data/nccf/com/gfs/prod/" target="_blank" rel="noopener">GFS 报文存档（NOMADS）</a></p><button id="selectedHourRecord" type="button">${zh ? '为该对象记录巡检维修事项' : 'Record an inspection or maintenance item'}</button></section>`;
    $("#selectedHourRecord").addEventListener('click', () => window.dispatchEvent(new CustomEvent('open-manual-records', {detail: {selected_time: context.selected_time}})));
    return;
  }
  const isM2 = p.asset_id === "FLATIRONS_MET_M2";
  $("#assetState").textContent = isM2 ? t("latestM2") : t("siteWeatherContext");
  $("#assetStateNote").textContent = isM2 ? `${fmt(DATA.current_observation.wind_speed_80m_mps, 2)} m/s · SRC-026` : `${fmt(forecastAt().wind_speed_80m_screen_mps, 2)} m/s · ${state.stress ? t("simulated") : "GFS"}`;
  const role = $("#assetRole");
  role.className = `role ${isM2 ? "role-observed" : state.stress ? "role-simulated" : "role-model"}`;
  role.textContent = isM2 ? t("observed") : state.stress ? t("simulated") : t("modelDerived");
  $("#inspectorContent").innerHTML = state.rightTab === "operation" ? operationHtml(feature) : state.rightTab === "risk" ? riskHtml() : state.rightTab === "state" ? stateHtml(feature) : state.rightTab === "maintenance" ? maintenanceHtml() : evidenceHtml(feature);
  window.lucide?.createIcons();
}

function renderTimeline() {
  if (state.browseWeather) {
    const context = state.browseWeather;
    const row = context.row;
    const zh = state.language === 'zh';
    currentWind = 0;
    $('[data-i18n="siteWind"]').textContent = zh ? '所选时段风速' : 'Selected weather wind';
    $('[data-i18n="forecastHorizon"]').textContent = zh ? '资料类型' : 'Data type';
    $('[data-i18n="weatherScreen"]').textContent = zh ? '设备状态' : 'Device status';
    $("#headerWind").textContent = row ? `${fmt(context.forecast ? row.wind_high_mps : row.wind_mps, 2)} m/s` : '—';
    $("#headerHorizon").textContent = context.research ? (context.mode === 'raw' ? 'GFS raw' : 'GFS corrected') : context.forecast ? 'NWS' : context.mode;
    $("#headerRisk").textContent = zh ? '未接遥测' : 'No telemetry';
    const roles = $$('.header-status .role');
    roles[0].textContent = row ? context.research || context.forecast ? t('forecast') : t('observed') : t('unavailable');
    roles[0].className = `role ${context.research ? 'role-model' : context.forecast ? 'role-forecast' : 'role-observed'}`;
    roles[1].textContent = context.research || context.forecast ? t('forecast') : t('observed');
    roles[1].className = `role ${context.research ? 'role-model' : context.forecast ? 'role-forecast' : 'role-observed'}`;
    roles[2].textContent = t('unavailable');
    roles[2].className = 'role role-unavailable';
    layerGroups.risk.visible = false;
    labelRecords.forEach(label => label.element.classList.remove('risk'));
    renderInspector();
    return;
  }
  const record = forecastAt();
  const lead = DATA.stress_test.lead_hours[state.horizonIndex];
  currentWind = Number(record.wind_speed_80m_screen_mps);
  $("#headerWind").textContent = `${fmt(DATA.current_observation.wind_speed_80m_mps, 2)} m/s`;
  $("#headerHorizon").textContent = `H${lead}`;
  $("#headerRisk").textContent = t(riskLevel(record));
  $("#validTime").textContent = state.stress
    ? `${t("simulatedStress")} · H${lead}`
    : new Date(record.valid_time_utc).toLocaleString(state.language === "en" ? "en-GB" : "zh-CN", {day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: "UTC", hour12: false}) + " UTC";
  $("#timeRole").innerHTML = state.stress ? `<span class="role role-simulated">${esc(t("simulated"))}</span> ${esc(t("stressTestSub"))}` : `<span class="role role-forecast">${state.language === "zh" ? "历史预报回放" : "Archived forecast playback"}</span> NOAA GFS`;
  $("#deckWind").textContent = `${fmt(record.wind_speed_80m_screen_mps, 2)} m/s`;
  $("#deckChange").textContent = record.three_hour_change_mps === null ? "--" : `${record.three_hour_change_mps >= 0 ? "+" : ""}${fmt(record.three_hour_change_mps, 2)} m/s`;
  $("#deckPower").textContent = record.wind_power_mw_scenario === null || record.wind_power_mw_scenario === undefined ? t("unavailable") : `${fmt(record.wind_power_mw_scenario, 3)} MW`;
  renderSparkline();
  updateRiskScene(record);
  renderInspector();
}

function renderSparkline() {
  const values = state.stress ? DATA.stress_test.wind_speed_80m_mps.map(Number) : DATA.forecast.map(row => Number(row.wind_speed_80m_screen_mps));
  const width = 460, height = 58, padX = 20, padTop = 7, padBottom = 10;
  const maxValue = Math.max(8, ...values) * 1.08;
  const points = values.map((value, index) => ({
    x: padX + index / (values.length - 1) * (width - padX * 2),
    y: padTop + (1 - value / maxValue) * (height - padTop - padBottom),
    value,
  }));
  const path = points.map((point, index) => `${index ? "L" : "M"}${point.x.toFixed(1)},${point.y.toFixed(1)}`).join(" ");
  const area = `${path} L${points.at(-1).x.toFixed(1)},${height-padBottom} L${points[0].x.toFixed(1)},${height-padBottom} Z`;
  $("#forecastSparkline").innerHTML = `
    <line class="grid" x1="${padX}" x2="${width-padX}" y1="${height-padBottom}" y2="${height-padBottom}"></line>
    <path class="${state.stress ? "stress-area" : "area"}" d="${area}"></path>
    <path class="${state.stress ? "stress-line" : "line"}" d="${path}"></path>
    ${points.map((point, index) => `<circle class="point ${index === state.horizonIndex ? "active" : ""}" cx="${point.x}" cy="${point.y}" r="${index === state.horizonIndex ? 4.2 : 3}"></circle>`).join("")}
    <text x="${width-55}" y="9">${maxValue.toFixed(0)} m/s</text>
  `;
  $("#horizonSteps").innerHTML = DATA.stress_test.lead_hours.map((lead, index) => `<button type="button" class="${index === state.horizonIndex ? "active" : ""}" data-horizon="${index}">H${lead}</button>`).join("");
  $$("[data-horizon]", $("#horizonSteps")).forEach(button => button.addEventListener("click", () => {
    state.horizonIndex = Number(button.dataset.horizon);
    renderTimeline();
  }));
}

function updateRiskScene(record) {
  const level = riskLevel(record);
  const riskVisible = state.visualMode === "risk" || state.stress;
  layerGroups.risk.visible = riskVisible;
  layerGroups.risk.traverse(object => {
    if (object.type === "ArrowHelper" || object.userData.riskArrow) {
      object.setColor?.(new THREE.Color(level === "critical" ? 0xb94c4b : level === "advisory" ? 0xcba34c : 0x5da9c0));
    }
    if (object.material?.color && object.geometry?.type === "RingGeometry") object.material.color.set(level === "critical" ? 0xb94c4b : 0xcba34c);
  });
  labelRecords.forEach(recordLabel => recordLabel.element.classList.toggle("risk", level !== "normal" && recordLabel.feature.properties.kind === "wind_turbine"));
  document.body.classList.toggle("stress-active", state.stress);
}

function applyLanguage() {
  document.documentElement.lang = state.language;
  document.title = state.language === "en"
    ? "Flatirons Renewable Energy Risk Twin"
    : "Flatirons 可再生能源风险孪生";
  $$('[data-i18n]').forEach(element => element.textContent = t(element.dataset.i18n));
  $("#languageButton").textContent = state.language === "en" ? "中文" : "EN";
  $("#assetSearch").placeholder = t("findAsset");
  renderAssetList();
  renderTimeline();
  renderInspector();
  labelRecords.forEach(record => $("b", record.element).textContent = shortName(record.feature));
  window.lucide?.createIcons();
}

function bindUi() {
  window.lucide?.createIcons();
  $$("[data-camera]").forEach(button => button.addEventListener("click", () => setCamera(button.dataset.camera)));
  $("#resetCameraButton").addEventListener("click", () => setCamera("overview"));
  $("#languageButton").addEventListener("click", () => { state.language = state.language === "en" ? "zh" : "en"; applyLanguage(); });
  $("#assetPanelButton").addEventListener("click", () => togglePanel("assetPanel"));
  $("#inspectorPanelButton").addEventListener("click", () => togglePanel("inspectorPanel"));
  $$("[data-close]").forEach(button => button.addEventListener("click", () => togglePanel(button.dataset.close, false)));
  $("#evidenceButton").addEventListener("click", () => toggleEvidence(true));
  $("#closeEvidenceButton").addEventListener("click", () => toggleEvidence(false));
  $$("[data-left-tab]").forEach(button => button.addEventListener("click", () => {
    state.leftTab = button.dataset.leftTab;
    $$("[data-left-tab]").forEach(item => item.classList.toggle("active", item === button));
    $$(".left-view").forEach(view => view.classList.toggle("active", view.id === `left${state.leftTab[0].toUpperCase()}${state.leftTab.slice(1)}`));
  }));
  $$("[data-right-tab]").forEach(button => button.addEventListener("click", () => {
    state.rightTab = button.dataset.rightTab;
    $$("[data-right-tab]").forEach(item => item.classList.toggle("active", item === button));
    renderInspector();
  }));
  $("#assetSearch").addEventListener("input", renderAssetList);
  $$("[data-filter]").forEach(button => button.addEventListener("click", () => {
    state.assetFilter = button.dataset.filter;
    $$("[data-filter]").forEach(item => item.classList.toggle("active", item === button));
    renderAssetList();
  }));
  $$("[data-layer]").forEach(input => input.addEventListener("change", () => {
    const layer = input.dataset.layer;
    if (layer === "labels") state.labelsVisible = input.checked;
    else if (layerGroups[layer]) layerGroups[layer].visible = input.checked;
  }));
  $$("[data-visual]").forEach(button => button.addEventListener("click", () => {
    state.visualMode = button.dataset.visual;
    $$("[data-visual]").forEach(item => item.classList.toggle("active", item === button));
    document.body.classList.toggle("risk-view", state.visualMode === "risk");
    if (state.visualMode === "risk") setCamera("wind");
    updateRiskScene(forecastAt());
  }));
  $("#stressToggle").addEventListener("change", event => {
    state.stress = event.target.checked;
    if (state.stress) {
      state.visualMode = "risk";
      $$("[data-visual]").forEach(button => button.classList.toggle("active", button.dataset.visual === "risk"));
      document.body.classList.add("risk-view");
      const selectedKind = state.selected?.properties.kind;
      if (selectedKind !== "wind_turbine") {
        const centralTurbine = DATA.geospatial_assets.features.find(feature => feature.properties.asset_id === "FLATIRONS_WTG_03");
        selectFeature(centralTurbine, false);
      }
      state.rightTab = "risk";
      $$("[data-right-tab]").forEach(button => button.classList.toggle("active", button.dataset.rightTab === "risk"));
      setCamera("wind");
      showToast(state.language === "en" ? "Simulated stress test enabled. No current-event or device-control claim is made." : "已启用模拟压力测试。", 3600);
    }
    renderTimeline();
  });
}

function togglePanel(id, force) {
  const panel = $(`#${id}`);
  if (innerWidth <= 760) {
    const open = force ?? !panel.classList.contains("mobile-open");
    $$(".side-panel").forEach(item => item.classList.remove("mobile-open"));
    if (open) panel.classList.add("mobile-open");
  } else {
    const open = force ?? panel.classList.contains("collapsed");
    panel.classList.toggle("collapsed", !open);
  }
}

function toggleEvidence(open) {
  $("#evidenceDrawer").classList.toggle("open", open);
  $("#evidenceDrawer").setAttribute("aria-hidden", String(!open));
}

let toastTimer;
function showToast(message, duration = 2600) {
  clearTimeout(toastTimer);
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  toastTimer = setTimeout(() => toast.classList.remove("show"), duration);
}

function updateRuntimeAudit() {
  if (!renderer) return;
  const overflow = [...document.body.querySelectorAll("*")].filter(element => {
    const style = getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden") return false;
    if (["auto", "scroll", "hidden", "clip"].includes(style.overflowX)) return false;
    return element.clientWidth > 0 && element.scrollWidth > element.clientWidth + 2;
  }).slice(0, 20).map(element => element.id || element.className || element.tagName);
  const audit = {
    viewport: {width: innerWidth, height: innerHeight},
    canvas: {width: renderer.domElement.width, height: renderer.domElement.height},
    webgl_context_lost: renderer.getContext().isContextLost(),
    render_triangles: renderer.info.render.triangles,
    mapped_assets: DATA.geospatial_assets.features.length,
    scene_counts: {
      turbines: layerGroups.wind.children.length,
      pv_areas: layerGroups.pv.children.length,
      met_towers: layerGroups.met.children.length,
      buildings_and_grid: layerGroups.buildings.children.length,
    },
    labels: labelRecords.length,
    document_horizontal_overflow_px: Math.max(0, document.documentElement.scrollWidth - innerWidth),
    unexpected_overflow_elements: overflow,
    selected_asset: state.selected?.properties.asset_id || null,
    stress_test: state.stress,
    horizon_index: state.horizonIndex,
  };
  $("#runtimeAudit").textContent = JSON.stringify(audit);
  window.__TWIN_QA__ = audit;
}

function init() {
  const query = new URLSearchParams(location.search);
  if (query.get("lang") === "zh") state.language = "zh";
  if (query.get("stress") === "1") {
    state.stress = true;
    state.visualMode = "risk";
  }
  if (query.has("h")) state.horizonIndex = clamp(Number(query.get("h")) || 0, 0, DATA.stress_test.lead_hours.length - 1);
  if (["operation", "risk", "state", "maintenance", "evidence"].includes(query.get("tab"))) state.rightTab = query.get("tab");
  initScene();
  bindUi();
  renderAssetList();
  const requestedAsset = query.get("asset");
  const defaultFeature = DATA.geospatial_assets.features.find(feature => feature.properties.asset_id === requestedAsset)
    || DATA.geospatial_assets.features.find(feature => feature.properties.asset_id === "FLATIRONS_WTG_01");
  selectFeature(defaultFeature, query.get("focus") === "1");
  $("#stressToggle").checked = state.stress;
  document.body.classList.toggle("stress-active", state.stress);
  document.body.classList.toggle("risk-view", state.visualMode === "risk");
  $$("[data-visual]").forEach(button => button.classList.toggle("active", button.dataset.visual === state.visualMode));
  $$("[data-right-tab]").forEach(button => button.classList.toggle("active", button.dataset.rightTab === state.rightTab));
  renderTimeline();
  applyLanguage();
  if (query.has("camera") && cameraPresets[query.get("camera")]) setCamera(query.get("camera"), false);
  if (query.get("drawer") === "1") toggleEvidence(true);
  setTimeout(updateRuntimeAudit, 1200);
}

window.addEventListener("select-twin-asset", event => {
  const feature = DATA.geospatial_assets.features.find(item => item.properties.asset_id === event.detail.asset_id);
  if (feature) selectFeature(feature, false);
});

window.addEventListener('browse-site-weather', event => {
  state.browseWeather = event.detail;
  if (event.detail) {
    state.stress = false;
    $('#stressToggle').checked = false;
    document.body.classList.remove('stress-active');
  }
  renderTimeline();
});

init();
window.dispatchEvent(new CustomEvent('twin-scene-ready'));


// TAB-REFRESH-FIX：有小时数据时，五个标签也要跟着切换
(function () {
  if (typeof renderInspector !== 'function') return;
  const _orig = renderInspector;
  const tabBlock = function (feature) {
    try {
      if (state.rightTab === 'operation') return operationHtml(feature);
      if (state.rightTab === 'risk') return riskHtml();
      if (state.rightTab === 'state') return stateHtml(feature);
      if (state.rightTab === 'maintenance') return maintenanceHtml();
      return evidenceHtml(feature);
    } catch (e) { return ''; }
  };
  renderInspector = function () {
    _orig();
    const host = document.getElementById('inspectorContent');
    if (!host || !state || !state.selected) return;
    const html = tabBlock(state.selected);
    if (html) host.insertAdjacentHTML('afterbegin', '<div class="tab-body">' + html + '</div>');
    if (window.lucide && window.lucide.createIcons) window.lucide.createIcons();
  };
  document.querySelectorAll('[data-right-tab]').forEach(function (btn) {
    btn.addEventListener('click', function () { setTimeout(renderInspector, 0); });
  });
})();

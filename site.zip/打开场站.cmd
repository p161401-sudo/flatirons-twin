@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 正在启动 Flatirons 场站本地服务……
set PY=
where pythonw >nul 2>nul && set PY=pythonw
if not defined PY where python >nul 2>nul && set PY=python
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set PY="%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PY if exist "C:\Users\19099\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe" set PY="C:\Users\19099\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
if not defined PY (
  echo 未找到 Python，请先安装 Python 3.10 以上版本，或在演示包中放入便携版。
  pause
  exit /b 1
)
start "" %PY% "场站服务.py" --open
echo 服务已启动，浏览器将自动打开；如未打开，请手动访问 http://127.0.0.1:8876/index.html?lang=zh
timeout /t 4 >nul

$ErrorActionPreference = "Stop"
$demoRoot = $PSScriptRoot
$url = "http://127.0.0.1:8876/index.html"

Write-Host "Flatirons Renewable Energy Risk Twin"
Write-Host "Serving: $demoRoot"

if (Get-Command py -ErrorAction SilentlyContinue) {
    $python = (Get-Command py).Source
    $pythonArgs = @('-3', '-m', 'http.server', '8876', '--bind', '127.0.0.1', '--directory', $demoRoot)
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $python = (Get-Command python).Source
    $pythonArgs = @('-m', 'http.server', '8876', '--bind', '127.0.0.1', '--directory', $demoRoot)
} else {
    throw "Python 3 is required to start the local static server."
}

$server = Start-Process -FilePath $python -ArgumentList $pythonArgs -WindowStyle Hidden -PassThru
try {
    $ready = $false
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        Start-Sleep -Milliseconds 200
        try {
            $response = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 2
            if ($response.StatusCode -eq 200) {
                $ready = $true
                break
            }
        } catch {
        }
    }
    if (-not $ready) {
        throw "Local web service did not become available at $url."
    }
    Write-Host "Opening: $url"
    Start-Process $url
    Write-Host "Press Ctrl+C to stop the local web service."
    Wait-Process -Id $server.Id
} finally {
    if ($server -and -not $server.HasExited) {
        Stop-Process -Id $server.Id -Force
    }
}

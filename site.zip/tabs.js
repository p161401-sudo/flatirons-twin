// 让右栏五个标签在有小时数据时也能切换：在原渲染结果后面追加当前标签内容。
(function () {
  if (typeof renderInspector !== 'function') return;

  const original = renderInspector;

  function tabHtml(feature) {
    try {
      if (state.rightTab === 'operation') return operationHtml(feature);
      if (state.rightTab === 'risk') return riskHtml();
      if (state.rightTab === 'state') return stateHtml(feature);
      if (state.rightTab === 'maintenance') return maintenanceHtml();
      return evidenceHtml(feature);
    } catch (e) {
      return '';
    }
  }

  renderInspector = function () {
    original();
    const host = document.getElementById('inspectorContent');
    if (!host || !state || !state.selected) return;
    const html = tabHtml(state.selected);
    if (html) host.insertAdjacentHTML('beforeend', '<div class="tab-body">' + html + '</div>');
    if (window.lucide && window.lucide.createIcons) window.lucide.createIcons();
  };

  // 标签点击后重新渲染一次，确保内容跟着换
  document.querySelectorAll('[data-right-tab]').forEach(function (btn) {
    btn.addEventListener('click', function () { setTimeout(renderInspector, 0); });
  });

  if (document.readyState !== 'loading') {
    try { renderInspector(); } catch (e) {}
  }
})();

$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot '复现研究.ps1') -Visual
if ($LASTEXITCODE -ne 0) {
    throw "Research and visual verification failed: $LASTEXITCODE"
}

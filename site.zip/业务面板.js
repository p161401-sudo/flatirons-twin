(() => {
  const root = document.createElement('section');
  root.id = 'operationsPanel';
  root.className = 'operations-panel';
  root.setAttribute('aria-label', '气象查询与运维记录 Weather and maintenance records');
  const zh = () => document.documentElement.lang.startsWith('zh');
  const words = (cn, en) => zh() ? cn : en;
  const escape = value => String(value ?? '').replace(/[&<>"']/g, character => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[character]));
  const number = value => value === null || value === undefined || !Number.isFinite(Number(value)) ? '—' : Number(value).toFixed(2);
  const date = value => value ? new Date(value).toLocaleString(zh() ? 'zh-CN' : 'en-GB', {timeZone: 'UTC', hour12: false}) + ' UTC' : '—';
  let active = 'weather';
  let latest = null;
  let records = [];
  let editing = null;
  let selectedAsset = null;
  let historyRows = [];
  let forecastSnapshots = [];
  let assets = {};
  let loading = false;
  const query = selector => root.querySelector(selector);
  const text = (id, value) => { query(id).textContent = value; };

  async function api(path, value) {
    const response = await fetch(path, {cache: 'no-store', ...(value === undefined ? {} : {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(value)})});
    if (!response.headers.get('Content-Type')?.includes('application/json')) throw new Error(words('当前仍是静态网页服务，请关闭旧服务并运行“打开场站.cmd”。', 'The static server has no data API. Restart using 打开场站.cmd.'));
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
    return body;
  }

  root.innerHTML = `
    <header class="operations-heading"><div><h2 data-cn="场站气象与运维记录" data-en="Site weather and maintenance records"></h2><p data-cn="公开气象定时获取；巡检维修记录由使用者填写，设备遥测尚未接入。" data-en="Public weather is polled periodically. Maintenance entries are entered manually; device telemetry is not connected."></p></div><button type="button" id="closeOperations" data-cn="返回三维场景" data-en="Back to 3D scene"></button></header>
    <nav class="operations-tabs"><button type="button" data-op-tab="weather" data-cn="最新天气与未来预报" data-en="Latest weather and forecasts"></button><button type="button" data-op-tab="history" data-cn="历史观测与预报回放" data-en="Observations and forecast archive"></button><button type="button" data-op-tab="records" data-cn="巡检维修记录" data-en="Inspection and maintenance"></button></nav>
    <p id="operationsMessage" role="status" aria-live="polite"></p>
    <div class="operations-body">
      <section data-op-view="weather">
        <div class="operations-row"><h3 data-cn="公开气象数据" data-en="Public weather data"></h3><button type="button" id="refreshWeather" data-cn="检查更新" data-en="Check for updates"></button></div>
        <p class="operations-note" data-cn="服务运行时每10分钟向来源查询一次；不是毫秒级实时监控。附近站观测、官方逐小时预报与论文GFS订正实验分别显示，不互相替代。" data-en="Sources are polled every 10 minutes while the service runs, not streamed in real time. Nearby observations, official hourly forecasts and the paper’s GFS correction experiments are separate products."></p>
        <div id="weatherSummary" class="operations-cards"></div>
        <div id="sourceState"></div>
        <div class="operations-row"><h3 data-cn="从当前时刻往后的官方逐小时预报" data-en="Official hourly forecasts from now onward"></h3><label><span data-cn="显示时长" data-en="Window"></span> <select id="forecastWindow"><option value="48">48 h</option><option value="168">7 d</option></select></label></div>
        <p class="operations-note" data-cn="NWS场址格点预报，不是逐台设备测量，也不是本文机器学习模型的在线预测；风速高度未在该响应中给出，不换算成80 m。降水概率不是高风风险概率。" data-en="NWS grid forecast for the site, not device measurements or live inference from the paper’s ML model. The response does not specify wind height; values are not converted to 80 m. Precipitation probability is not high-wind event probability."></p>
        <div id="futureChart"></div><div class="operations-table-wrap" id="futureTable"></div>
        <h3 data-cn="来源发布的天气通告" data-en="Official weather alerts"></h3><div id="officialAlerts"></div>
      </section>
      <section data-op-view="history" hidden>
        <h3 data-cn="按日期查询已保存的观测" data-en="Query saved observations by date"></h3>
        <p class="operations-note" id="historyCoverage"></p>
        <form id="historyQuery" class="operations-row"><label><span data-cn="测站" data-en="Station"></span><select id="historyStation"><option value="M2">M2 · 80 m · 2025 / 2026 Q1</option><option value="KBJC">KBJC · NWS</option></select></label><label><span data-cn="开始日期 UTC" data-en="First date UTC"></span><input type="date" id="historyStart" value="2026-01-01" required></label><label><span data-cn="结束日期 UTC（含当天）" data-en="Last date UTC (inclusive)"></span><input type="date" id="historyEnd" value="2026-03-31" required></label><button type="submit" data-cn="查询观测" data-en="Query observations"></button></form>
        <p class="operations-note" data-cn="M2只查询已导入的2025年与2026年第一季度有效小时观测；其他日期显示无记录，不插值、不补零。KBJC从本服务首次接入后开始积累，不声称已保存此前全部历史。" data-en="M2 queries use imported valid hourly observations for 2025 and Q1 2026. Missing dates stay missing, without interpolation or zero filling. KBJC history accumulates from the first retrieval, not from an assumed earlier archive."></p>
        <div id="historyResult"></div><div id="historyChart"></div><div id="historyRows" class="operations-table-wrap"></div>
        <h3 data-cn="已获取的官方预报版本" data-en="Saved official forecast versions"></h3><p class="operations-note" data-cn="从接入后开始保存每份不同预报，保留发布时间和SHA-256；回放使用当时发布的预报，不用后来实况替换。" data-en="Distinct forecast responses are archived from connection onward with issue time and SHA-256. Replay uses the published forecast, never later observations."></p>
        <div class="operations-row"><select id="forecastArchive" aria-label="Archived forecast version"></select><button type="button" id="replayForecast" data-cn="回放此版本" data-en="Replay version"></button></div><div id="forecastReplay" class="operations-table-wrap"></div>
      </section>
      <section data-op-view="records" hidden>
        <h3 data-cn="按设备保存巡检与维修事项" data-en="Save inspections and maintenance by asset"></h3>
        <p class="operations-note" data-cn="本页是本机人工台账，不是场站SCADA或既有CMMS接口。新增记录由填写者负责，保存后重启服务仍保留；修改保存前后版本，不自动生成故障或宣称完成检修。" data-en="This is a local manual log, not SCADA or an existing CMMS connection. Entries persist after restart and keep revision history; the system does not invent faults or completed work."></p>
        <form id="workorderForm" class="operations-form"><label><span data-cn="关联对象" data-en="Asset"></span><select id="recordAsset" required></select></label><label><span data-cn="事项类别" data-en="Category"></span><select id="recordCategory"><option>巡检</option><option>维修</option><option>天气复核</option><option>其他</option></select></label><label><span data-cn="事项标题" data-en="Title"></span><input id="recordTitle" maxlength="180" required></label><label><span data-cn="记录人" data-en="Entered by"></span><input id="recordAuthor" maxlength="180" required></label><label><span data-cn="事项时间 UTC" data-en="Event time UTC"></span><input type="datetime-local" id="recordTime" required></label><label><span data-cn="处理状态" data-en="Status"></span><select id="recordStatus"><option>待处理</option><option>处理中</option><option>已完成</option></select></label><label class="operations-wide"><span data-cn="实际记录内容" data-en="Record details"></span><textarea id="recordDescription" maxlength="6000" required rows="3"></textarea></label><div class="operations-wide operations-row"><button type="submit" id="saveRecord" data-cn="保存人工记录" data-en="Save manual entry"></button><button type="button" id="cancelRecord" data-cn="清空编辑" data-en="Clear editor"></button><button type="button" id="exportRecords" data-cn="导出本机记录 JSON" data-en="Export local records JSON"></button></div></form>
        <div id="recordList"></div><pre id="recordHistory" class="operations-note"></pre>
      </section>
    </div>`;
  document.body.append(root);
  const opener = document.createElement('button');
  opener.type = 'button';
  opener.id = 'openOperations';
  opener.className = 'operations-open';
  opener.addEventListener('click', () => { root.hidden = false; });
  document.body.append(opener);

  function labels() {
    root.querySelectorAll('[data-cn]').forEach(element => { element.textContent = zh() ? element.dataset.cn : element.dataset.en; });
    const translations = {'巡检': 'Inspection', '维修': 'Maintenance', '天气复核': 'Weather review', '其他': 'Other', '待处理': 'Pending', '处理中': 'In progress', '已完成': 'Completed'};
    root.querySelectorAll('#recordCategory option, #recordStatus option').forEach(option => {
      if (!option.hasAttribute('value')) option.value = option.textContent;
      option.textContent = zh() ? option.value : translations[option.value];
    });
    opener.textContent = words('天气查询与运维记录', 'Weather and maintenance');
  }

  function setTab(name) {
    active = name;
    root.hidden = false;
    root.querySelector('.operations-body').scrollTop = 0;
    root.querySelectorAll('[data-op-view]').forEach(element => { element.hidden = element.dataset.opView !== name; });
    root.querySelectorAll('[data-op-tab]').forEach(element => { element.classList.toggle('active', element.dataset.opTab === name); });
    if (name === 'history') loadArchive().catch(showError);
    if (name === 'records') loadRecords().catch(showError);
  }

  function showError(error) { text('#operationsMessage', error.message); query('#operationsMessage').className = 'operations-error'; }
  function message(value) { text('#operationsMessage', value); query('#operationsMessage').className = ''; }

  function chart(rows, valueKey, title) {
    const valid = rows.filter(row => row[valueKey] !== null && Number.isFinite(Number(row[valueKey])));
    if (!valid.length) return `<p>${escape(words('该范围没有有效数值。', 'No valid values in this interval.'))}</p>`;
    const width = 960, height = 190, pad = 44;
    const minTime = Math.min(...rows.map(row => Date.parse(row.time)));
    const maxTime = Math.max(...rows.map(row => Date.parse(row.time)));
    const maximum = Math.max(1, ...valid.map(row => Number(row[valueKey]))) * 1.1;
    let previous = null;
    const path = rows.map(row => {
      if (row[valueKey] === null || !Number.isFinite(Number(row[valueKey]))) { previous = null; return ''; }
      const current = Date.parse(row.time);
      const connect = previous !== null && current - previous <= 5400000;
      previous = current;
      return `${connect ? 'L' : 'M'}${(pad + (current - minTime) / Math.max(1, maxTime - minTime) * (width - pad * 2)).toFixed(1)},${(height - pad - Number(row[valueKey]) / maximum * (height - pad * 2)).toFixed(1)}`;
    }).join(' ');
    return `<svg class="operations-chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="${escape(title)}"><title>${escape(title)}</title><text x="44" y="16">${escape(title)}</text><line x1="44" y1="146" x2="916" y2="146" stroke="#a7b6bb"/><path d="${path}" fill="none" stroke="#267c8c" stroke-width="2"/><text x="4" y="48">${maximum.toFixed(1)}</text><text x="12" y="146">0</text><text x="44" y="181">${escape(date(new Date(minTime).toISOString()))}</text><text x="916" y="181" text-anchor="end">${escape(date(new Date(maxTime).toISOString()))}</text></svg>`;
  }

  function renderWeather() {
    if (!latest) return;
    const observation = latest.observation;
    const obsState = latest.sources.kbjc_observation;
    const future = latest.forecast.filter(row => Date.parse(row.valid_to) > Date.now() && Date.parse(row.valid_from) < Date.now() + Number(query('#forecastWindow').value) * 3600000);
    query('#weatherSummary').innerHTML = `<article><small>${words('附近KBJC站地面观测，不是M2', 'Nearby KBJC observation, not M2')}</small><strong>${number(observation?.wind_mps)} m/s</strong><p>${date(observation?.observed_at)}</p><p>${words('温度', 'Temperature')} ${number(observation?.temperature_c)} °C</p><b>${!observation ? words('尚无数据', 'No data') : obsState?.stale ? words('观测已过时，请勿当作当前值', 'Observation is stale') : words('按来源观测时间显示', 'At the reported observation time')}</b></article><article><small>${words('NWS官方逐小时预报', 'Official NWS hourly forecast')}</small><strong>${future.length} ${words('个有效时段', 'valid periods')}</strong><p>${words('来源更新时间', 'Source update')} ${date(latest.forecast_issue_time)}</p><p>${words('并非论文GFS订正模型', 'Not the paper’s corrected GFS model')}</p></article>`;
    query('#sourceState').innerHTML = Object.entries(latest.sources).map(([name, state]) => `<p class="operations-source ${state.success === 0 || state.stale ? 'operations-warning' : ''}"><b>${escape(name)}</b> · ${state.success === 1 ? words('来源请求成功', 'Source request succeeded') : state.success === 0 ? words('请求失败，保留已有资料', 'Fetch failed; retained data only') : words('等待首次响应', 'Awaiting first response')} · ${words('查询时间', 'Checked')} ${date(state.checked_at)} ${state.stale ? ' · ' + words('资料过时', 'STALE') : ''}${state.hash ? `<details><summary>${words('来源与文件校验值', 'Source and checksum')}</summary><span>${escape(state.url)}<br>SHA-256 ${escape(state.hash)}</span></details>` : ''}${state.error ? `<span>${escape(state.error)}</span>` : ''}</p>`).join('');
    query('#futureChart').innerHTML = chart(future.map(row => ({...row, time: row.valid_from})), 'wind_high_mps', words('NWS格点预报风速上界 m/s（非概率区间）', 'NWS grid wind upper value m/s (not a probability interval)'));
    query('#futureTable').innerHTML = `<table><thead><tr><th>${words('有效时间 UTC', 'Valid time UTC')}</th><th>${words('预报风速 m/s', 'Forecast wind m/s')}</th><th>${words('温度 °C', 'Temperature °C')}</th><th>${words('降水概率 %', 'Precipitation %')}</th><th>${words('官方天气描述', 'Official weather text')}</th></tr></thead><tbody>${future.map(row => `<tr><td>${date(row.valid_from)}</td><td>${number(row.wind_low_mps)}–${number(row.wind_high_mps)} ${escape(row.wind_direction)}</td><td>${number(row.temperature_c)}</td><td>${number(row.precipitation_probability_pct)}</td><td>${escape(row.summary)}</td></tr>`).join('')}</tbody></table>`;
    query('#officialAlerts').innerHTML = latest.alerts.length ? latest.alerts.map(alert => `<article class="operations-warning"><b>${escape(alert.event)} · ${escape(alert.severity)}</b><p>${escape(alert.headline)}</p><p>${date(alert.onset)} — ${date(alert.expires)}</p><p>${escape(alert.instruction)}</p></article>`).join('') : `<p>${latest.sources.nws_alerts?.success === 1 ? words('来源当前响应未列出场址有效通告；这不等于设备安全保证。', 'No active alerts were returned for this point; this is not a device safety guarantee.') : words('天气通告尚未成功获取，不能解释为无预警。', 'Alerts unavailable; do not interpret this as an all-clear.')}</p>`;
  }

  async function loadWeather() {
    if (loading) return;
    loading = true;
    try { latest = await api('/api/weather/latest'); renderWeather(); message(latest.refreshing ? words('正在向公开来源获取数据……', 'Fetching public source data…') : words('时间均标为UTC；场景可按日期和小时选择观测或预报，设备遥测尚未接入。', 'All times are UTC. Select observations or forecasts by date and hour in the scene; device telemetry is not connected.')); }
    catch (error) { showError(error); }
    finally { loading = false; }
  }

  async function loadArchive() {
    forecastSnapshots = await api('/api/weather/forecasts');
    query('#forecastArchive').innerHTML = forecastSnapshots.map(row => `<option value="${escape(row.hash)}">${date(row.source_time)} · ${escape(row.hash.slice(0, 12))}</option>`).join('');
    if (!forecastSnapshots.length) query('#forecastReplay').textContent = words('尚无已获取的预报版本。', 'No forecast version has been retrieved yet.');
  }

  async function loadRecords() {
    records = await api('/api/workorders');
    query('#recordList').innerHTML = records.length ? records.map(row => `<article class="operations-record"><b>${escape(row.title)}</b><p>${escape(row.asset_id)} · ${escape(row.category)} · ${escape(row.status)} · v${row.revision}</p><p>${escape(row.description)}</p><small>${date(row.event_at)} · ${escape(row.author)} · ${words('人工录入', 'Manual entry')}</small><div><button type="button" data-edit-record="${escape(row.id)}">${words('查看并修改', 'View and edit')}</button><button type="button" data-record-history="${escape(row.id)}">${words('修改历史', 'Revision history')}</button></div></article>`).join('') : `<p>${words('当前没有人工巡检或维修记录；系统没有生成示例工单。', 'No manual inspection or maintenance entries. No example work orders have been generated.')}</p>`;
  }

  function resetEditor() {
    editing = null;
    query('#workorderForm').reset();
    query('#recordTime').value = new Date().toISOString().slice(0, 16);
    if (selectedAsset && assets[selectedAsset]) query('#recordAsset').value = selectedAsset;
  }

  root.addEventListener('click', async event => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.dataset.opTab) setTab(button.dataset.opTab);
    if (button.id === 'closeOperations') root.hidden = true;
    if (button.id === 'cancelRecord') resetEditor();
    try {
      if (button.dataset.editRecord) {
        editing = records.find(row => row.id === button.dataset.editRecord);
        for (const [id, key] of [['recordAsset', 'asset_id'], ['recordCategory', 'category'], ['recordTitle', 'title'], ['recordDescription', 'description'], ['recordStatus', 'status'], ['recordAuthor', 'author']]) query('#' + id).value = editing[key];
        query('#recordTime').value = editing.event_at.slice(0, 16);
        query('#workorderForm').scrollIntoView({block: 'start'});
      }
      if (button.dataset.recordHistory) {
        const rows = await api('/api/workorders/history?id=' + encodeURIComponent(button.dataset.recordHistory));
        text('#recordHistory', rows.map(row => { const value = JSON.parse(row.payload); return `v${value.revision} · ${date(row.changed_at)} · ${value.author}\n${value.status} · ${value.title}\n${value.description}`; }).join('\n\n'));
      }
      if (button.id === 'refreshWeather') {
        button.disabled = true;
        await api('/api/weather/refresh', {});
        message(words('已请求更新；以各来源的查询时间和状态为准。', 'Refresh requested; check each source’s timestamp and status.'));
        setTimeout(() => { button.disabled = false; loadWeather(); }, 4000);
      }
      if (button.id === 'replayForecast' && query('#forecastArchive').value) {
        const snapshot = await api('/api/weather/forecast?hash=' + encodeURIComponent(query('#forecastArchive').value));
        const periods = JSON.parse(snapshot.payload).properties.periods;
        query('#forecastReplay').innerHTML = `<p>${words('来源发布时间', 'Source issue time')} ${date(snapshot.source_time)}<br>SHA-256 ${escape(snapshot.hash)}</p><table><thead><tr><th>UTC</th><th>${words('原始风速及单位', 'Original wind and unit')}</th><th>${words('官方天气描述', 'Official weather text')}</th></tr></thead><tbody>${periods.map(period => `<tr><td>${date(period.startTime)}</td><td>${escape(period.windSpeed)} ${escape(period.windDirection)}</td><td>${escape(period.shortForecast)}</td></tr>`).join('')}</tbody></table>`;
      }
      if (button.id === 'exportRecords') {
        const blob = new Blob([JSON.stringify({origin: 'manual_local_records', exported_at: new Date().toISOString(), records}, null, 2)], {type: 'application/json'});
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a'); link.href = url; link.download = '巡检维修记录.json'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
      }
    } catch (error) { showError(error); }
  });
  query('#forecastWindow').addEventListener('change', renderWeather);
  query('#historyQuery').addEventListener('submit', async event => {
    event.preventDefault();
    try {
      const start = query('#historyStart').value + 'T00:00:00Z';
      const end = new Date(query('#historyEnd').value + 'T00:00:00Z'); end.setUTCDate(end.getUTCDate() + 1);
      const result = await api('/api/weather/history?' + new URLSearchParams({station: query('#historyStation').value, start, end: end.toISOString()}));
      historyRows = result.rows;
      text('#historyResult', `${result.count} ${words('条已保存观测；没有记录的时刻不补值。', 'saved observations; missing times are not filled.')}`);
      query('#historyChart').innerHTML = chart(historyRows.map(row => ({...row, time: row.observed_at})), 'wind_mps', `${result.station} ${words('观测风速', 'observed wind')} (m/s)`);
      query('#historyRows').innerHTML = `<p>${words('下表列出前200条，曲线使用本次返回的全部记录。', 'First 200 rows below; the chart uses all returned observations.')}</p><table><thead><tr><th>UTC</th><th>${words('风速 m/s', 'Wind m/s')}</th><th>${words('测量高度 m', 'Height m')}</th><th>${words('来源', 'Source')}</th></tr></thead><tbody>${historyRows.slice(0, 200).map(row => `<tr><td>${date(row.observed_at)}</td><td>${number(row.wind_mps)}</td><td>${number(row.height_m)}</td><td>${escape(row.source)}</td></tr>`).join('')}</tbody></table>`;
    } catch (error) { showError(error); }
  });
  query('#workorderForm').addEventListener('submit', async event => {
    event.preventDefault();
    query('#saveRecord').disabled = true;
    try {
      const value = {asset_id: query('#recordAsset').value, category: query('#recordCategory').value, title: query('#recordTitle').value, description: query('#recordDescription').value, author: query('#recordAuthor').value, status: query('#recordStatus').value, event_at: query('#recordTime').value + ':00Z', revision: editing?.revision};
      await api('/api/workorders' + (editing ? '/' + editing.id : ''), value);
      resetEditor(); await loadRecords(); message(words('人工记录已保存到本机数据库。', 'Manual entry saved to the local database.'));
    } catch (error) { showError(error); }
    finally { query('#saveRecord').disabled = false; }
  });
  query('#recordAsset').addEventListener('change', () => window.dispatchEvent(new CustomEvent('select-twin-asset', {detail: {asset_id: query('#recordAsset').value}})));
  window.addEventListener('twin-asset-selected', event => { selectedAsset = event.detail.asset_id; if (!editing && assets[selectedAsset]) query('#recordAsset').value = selectedAsset; });
  new MutationObserver(() => { labels(); renderWeather(); if (active === 'records') loadRecords().catch(showError); }).observe(document.documentElement, {attributes: true, attributeFilter: ['lang']});
  window.addEventListener('open-manual-records', event => {
    setTab('records');
    if (!editing && event.detail?.selected_time) query('#recordTime').value = event.detail.selected_time.slice(0, 16);
  });
  labels(); setTab('weather'); root.hidden = true; resetEditor();
  Promise.all([api('/api/status'), api('/api/assets')]).then(([status, mapping]) => {
    assets = mapping;
    query('#recordAsset').innerHTML = Object.entries(assets).map(([id, asset]) => `<option value="${escape(id)}">${escape(id.replace('FLATIRONS_', ''))} · ${escape(asset.name)}</option>`).join('');
    text('#historyCoverage', status.coverage.map(row => `${row.station}: ${date(row.first_time)} — ${date(row.last_time)} · ${row.count}`).join(' | '));
    loadWeather();
  }).catch(showError);
  setInterval(loadWeather, 30000);
})();

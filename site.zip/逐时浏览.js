(() => {
  const panel = document.createElement('section');
  panel.id = 'hourlyBrowser';
  panel.setAttribute('aria-label', '逐日逐时气象浏览 Hourly weather browser');
  const zh = () => document.documentElement.lang.startsWith('zh');
  const words = (cn, en) => zh() ? cn : en;
  const escape = value => String(value ?? '').replace(/[&<>"']/g, letter => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[letter]));
  const find = selector => panel.querySelector(selector);
  const isoDay = value => new Date(value).toISOString().slice(0, 10);
  const initial = new Date();
  let chosen = new Date(Date.UTC(initial.getUTCFullYear(), initial.getUTCMonth(), initial.getUTCDate(), initial.getUTCHours()));
  let rows = [];
  let latest = null;
  let coverage = [];
  let timer = null;
  let requestVersion = 0;
  let selection = null;
  let busy = false;
  let replayVersions = [];
  let replayStatus = 'available';
  let selectedAsset = window.TWIN_DATA?.geospatial_assets.features.find(feature => feature.properties.kind !== 'site_boundary')?.properties.asset_id;
  panel.innerHTML = `<div class="hourly-controls"><label><span data-cn="资料" data-en="Dataset"></span><select id="hourlySource"><option value="forecast" data-cn="NWS最新逐小时预报" data-en="Latest NWS hourly forecast"></option><option value="M2" data-cn="M2历史观测 80米" data-en="M2 historical observations 80 m"></option><option value="KBJC" data-cn="KBJC已保存观测" data-en="Saved KBJC observations"></option></select></label><label><span data-cn="日期 UTC" data-en="Date UTC"></span><input id="hourlyDate" type="date" required></label><label><span data-cn="小时 UTC" data-en="Hour UTC"></span><select id="hourlyHour"></select></label><button type="button" id="previousDay" data-cn="前一天" data-en="Previous day"></button><button type="button" id="previousHour" data-cn="前一小时" data-en="Previous hour"></button><button type="button" id="hourlyPlay"></button><button type="button" id="nextHour" data-cn="后一小时" data-en="Next hour"></button><button type="button" id="nextDay" data-cn="后一天" data-en="Next day"></button><button type="button" id="hourlyRecords" data-cn="记录事项" data-en="Record an item"></button><button type="button" id="legacyArchive" data-cn="原GFS快照" data-en="Original GFS archive"></button></div><div class="hourly-summary"><strong id="hourlyValue"></strong><span id="hourlyStatus" role="status" aria-live="polite"></span></div><input id="hourlySlider" type="range" min="0" max="23" step="1" aria-label="所选日期的小时 Hour of selected day"><div id="hourlyCells" class="hourly-cells"></div>`;
  document.body.append(panel);
  find('#hourlySource').insertAdjacentHTML('beforeend', '<option value="raw" data-cn="研究GFS原始预报回放" data-en="Research GFS raw replay"></option><option value="corrected" data-cn="研究GFS订正预报回放" data-en="Research GFS corrected replay"></option>');

  async function api(route) {
    const response = await fetch(route, {cache: 'no-store'});
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    if (!response.headers.get('Content-Type')?.includes('application/json')) throw new Error(words('请通过打开场站.cmd启动服务。', 'Start the service using 打开场站.cmd.'));
    return response.json();
  }

  function stop() {
    clearInterval(timer);
    timer = null;
    find('#hourlyPlay').textContent = words('逐时播放', 'Play hourly');
    labels();
}

  function mode() { return find('#hourlySource').value; }
  function researchMode() { return mode() === 'raw' || mode() === 'corrected'; }
  function replayVersion() { return replayVersions.find(item => item.kind === mode()); }
  function timeOf(row) { return Date.parse(mode() === 'forecast' ? row.valid_from : row.observed_at); }
  function rowAt(hour) {
    const start = Date.parse(isoDay(chosen) + 'T00:00:00Z') + hour * 3600000;
    return rows.filter(row => mode() === 'forecast' ? Date.parse(row.valid_from) <= start && Date.parse(row.valid_to) > start : timeOf(row) >= start && timeOf(row) < start + 3600000).at(-1) || null;
  }

  function bounds() {
    if (researchMode()) {
      const version = replayVersion();
      return version ? [version.first_time, version.last_time] : null;
    }
    if (mode() === 'forecast') {
      const forecast = latest?.forecast || [];
      return forecast.length ? [forecast[0].valid_from, forecast.at(-1).valid_from] : null;
    }
    const station = coverage.find(item => item.station === mode());
    return station ? [station.first_time, station.last_time] : null;
  }

  function labels() {
    panel.querySelectorAll('[data-cn]').forEach(element => { element.textContent = zh() ? element.dataset.cn : element.dataset.en; });
    find('#legacyArchive').textContent = words('最新时刻', 'Latest hour');
    find('#hourlyPlay').textContent = timer ? words('暂停', 'Pause') : words('逐时播放', 'Play hourly');
  find('#hourlyPlay').classList.toggle('playing', Boolean(timer));
  find('#hourlyPlay').classList.toggle('playing', Boolean(timer));
  }

  function render() {
    labels();
    find('#hourlyDate').value = isoDay(chosen);
    find('#hourlyHour').innerHTML = Array.from({length: 24}, (_, hour) => `<option value="${hour}">${String(hour).padStart(2, '0')}:00${rowAt(hour) ? '' : words(' 无记录', ' no data')}</option>`).join('');
    find('#hourlyHour').value = String(chosen.getUTCHours());
    find('#hourlySlider').value = String(chosen.getUTCHours());
    const row = rowAt(chosen.getUTCHours());
    const forecast = mode() === 'forecast';
    const source = forecast ? latest?.sources.nws_forecast : null;
    const number = value => value === null || value === undefined ? '—' : Number(value).toFixed(2);
    find('#hourlyValue').textContent = `${chosen.toISOString().slice(0, 16).replace('T', ' ')} UTC · ${row ? forecast ? number(row.wind_low_mps) + '–' + number(row.wind_high_mps) + ' m/s' : number(row.wind_mps) + ' m/s' : words('无记录', 'No record')}`;
    const issue = researchMode() ? row?.issue_time : latest?.forecast_issue_time;
    const note = forecast ? words('NWS格点预报；未给出测量高度，不是80米设备实测。', 'NWS grid forecast; height unspecified, not an 80 m device measurement.') + (issue ? ' ' + words('来源更新 ', 'Source updated ') + issue : '') + (source?.success === 0 || source?.stale ? words('；请求失败或预报已过期，仅显示保存资料。', '; fetch failed or forecast stale: saved data only.') : '') : mode() === 'M2' ? words('M2测风塔80米历史观测；其他设备仅作空间关联。', 'Historical M2 80 m observation; other assets are spatial associations only.') : words('附近KBJC站已保存观测；不是场内设备实测。', 'Saved nearby KBJC observations, not on-site device measurements.');
    find('#hourlyStatus').textContent = note + words(' 北京时间为UTC加8小时；空缺不补值。', ' Beijing time is UTC+8; gaps are not filled.');
    const researchNote = researchMode() ? words('GFS研究预报回放，目标为M2测站80米风速；所选设备共享场址参考值。', 'Research GFS replay targeting M2 wind at 80 m; selected objects share a site reference.') + ' ' + words('版本 ' , 'Version ') + (replayVersion()?.version || '—') + (row ? ' · ' + words('起报 ' , 'Issued ') + row.issue_time + ' · H' + row.lead_hours : '') : note;
    if (researchMode()) find('#hourlyStatus').textContent = researchNote + words('；缺测小时不插值，统计筛查与设备风险分开显示。', '; missing hours are not interpolated; statistical screening is separate from equipment risk.');
    if (researchMode() && replayStatus === 'source_unavailable') find('#hourlyStatus').textContent += words(' 来源已停用，当前不返回数值。', ' Source unavailable; no numerical value is returned.');
    find('#hourlyCells').innerHTML = Array.from({length: 24}, (_, hour) => `<button type="button" data-hour="${hour}" class="${hour === chosen.getUTCHours() ? 'chosen' : ''} ${rowAt(hour) ? 'available' : 'missing'}" aria-label="${String(hour).padStart(2, '0')}:00 UTC ${rowAt(hour) ? words('有记录', 'available') : words('无记录', 'no record')}">${String(hour).padStart(2, '0')}</button>`).join('');
    const bound = bounds();
    find('#hourlyDate').min = bound ? isoDay(bound[0]) : '';
    find('#hourlyDate').max = bound ? isoDay(bound[1]) : '';
    const selectedHour = chosen.toISOString();
    selection = {mode: mode(), research: researchMode(), selected_time: selectedHour, row, source_time: researchMode() || forecast ? issue : row?.observed_at, source_url: forecast ? source?.url : null, source_hash: row?.source_hash || source?.hash, stale: Boolean(source?.stale || source?.success === 0), note: researchNote, forecast};
    window.dispatchEvent(new CustomEvent('browse-site-weather', {detail: selection}));
  }

  async function load() {
    const version = ++requestVersion;
    busy = true;
    find('#hourlyStatus').textContent = words('正在读取所选日期……', 'Loading selected date…');
    try {
      if (mode() === 'forecast') {
        if (!latest) latest = await api('/api/weather/latest');
        if (version !== requestVersion) return;
        rows = latest.forecast.filter(row => isoDay(row.valid_from) === isoDay(chosen));
      } else if (researchMode()) {
        if (!replayVersions.length) replayVersions = await api('/api/research/versions');
        const saved = replayVersion();
        if (!saved) throw new Error(words('研究预报尚未导入，请重新启动场站服务。', 'Research forecasts are not imported; restart the site service.'));
        const start = isoDay(chosen) + 'T00:00:00Z';
        const end = new Date(Date.parse(start) + 86400000).toISOString();
        const result = await api('/api/research/weather?' + new URLSearchParams({asset_id: selectedAsset, version: saved.version, start, end}));
        if (version !== requestVersion) return;
        replayStatus = result.status;
        rows = result.rows.map(row => ({...row, observed_at: row.valid_time, height_m: row.target_height_m, source_hash: result.source_hash}));
      } else {
        const start = isoDay(chosen) + 'T00:00:00Z';
        const end = new Date(Date.parse(start) + 86400000).toISOString();
        const result = await api('/api/weather/history?' + new URLSearchParams({station: mode(), start, end}));
        if (version !== requestVersion) return;
        rows = result.rows;
      }
      document.body.classList.add('hourly-active');
      render();
    } catch (error) {
      if (version !== requestVersion) return;
      rows = [];
      document.body.classList.add('hourly-active');
      render();
      find('#hourlyStatus').textContent = words('读取失败，当前小时未显示任何旧数值：', 'Load failed; no earlier value is shown: ') + error.message;
      stop();
    } finally { if (version === requestVersion) busy = false; }
  }

  async function move(hours) {
    if (busy) return;
    const next = new Date(chosen.getTime() + hours * 3600000);
    const bound = bounds();
    if (bound && (isoDay(next) < isoDay(bound[0]) || isoDay(next) > isoDay(bound[1]))) { stop(); return; }
    const changedDay = isoDay(next) !== isoDay(chosen);
    chosen = next;
    if (changedDay) await load(); else render();
  }

  panel.addEventListener('click', async event => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.hasAttribute('data-hour')) { stop(); chosen.setUTCHours(Number(button.dataset.hour)); render(); }
    if (button.id === 'previousHour') { stop(); await move(-1); }
    if (button.id === 'nextHour') { stop(); await move(1); }
    if (button.id === 'previousDay') { stop(); await move(-24); }
    if (button.id === 'nextDay') { stop(); await move(24); }
    if (button.id === 'hourlyPlay') {
      if (timer) stop();
    else {
      timer = setInterval(async () => {
        await move(1);
        const bound = bounds();
        if (bound && new Date(chosen) >= new Date(bound[1])) stop();
      }, 1500);
      labels();
    }
    }
    if (button.id === 'hourlyRecords') window.dispatchEvent(new CustomEvent('open-manual-records', {detail: {selected_time: chosen.toISOString()}}));
    if (button.id === 'legacyArchive') {
      stop();
      find('#hourlySource').value = 'forecast';
      chosen = new Date();
      chosen.setUTCMinutes(0, 0, 0);
      latest = await api('/api/weather/latest');
      await load();
    }
  });
  find('#hourlySource').addEventListener('change', async () => {
    stop();
    if (researchMode() && !replayVersions.length) {
      try { replayVersions = await api('/api/research/versions'); } catch { await load(); return; }
    }
    const bound = bounds();
    const withinRange = bound && chosen >= new Date(bound[0]) && chosen <= new Date(bound[1]);
    chosen = new Date(mode() === 'forecast' ? Date.now() : withinRange ? chosen : bound ? bound[1] : Date.now());
    chosen.setUTCMinutes(0, 0, 0);
    await load();
  });
  find('#hourlyDate').addEventListener('change', async () => {
    stop();
    if (!find('#hourlyDate').value) return;
    chosen = new Date(find('#hourlyDate').value + 'T' + String(chosen.getUTCHours()).padStart(2, '0') + ':00:00Z');
    await load();
  });
  find('#hourlyHour').addEventListener('change', () => { stop(); chosen.setUTCHours(Number(find('#hourlyHour').value)); render(); });
  find('#hourlySlider').addEventListener('input', () => { stop(); chosen.setUTCHours(Number(find('#hourlySlider').value)); render(); });
  window.addEventListener('twin-scene-ready', () => { if (selection) window.dispatchEvent(new CustomEvent('browse-site-weather', {detail: selection})); });
  window.addEventListener('twin-asset-selected', event => { selectedAsset = event.detail.asset_id; if (researchMode()) load(); });

  // 只有 M2 有 80 米逐时观测；M3–M5 仅有塔位。选中它们时把共享参考值标注清楚。
  const TOWER_WITHOUT_OBS = new Set(['FLATIRONS_MET_M3', 'FLATIRONS_MET_M4', 'FLATIRONS_MET_M5']);
  function refreshTowerNote() {
    let el = document.getElementById('towerNote');
    if (!el) {
      el = document.createElement('div');
      el.id = 'towerNote';
      el.style.cssText = 'margin:6px 0 0;font-size:12px;line-height:1.5;color:#7a5c12;' +
        'background:#fdf7e6;border-left:3px solid #c9a227;padding:5px 8px;border-radius:3px;';
      const status = document.getElementById('hourlyStatus');
      if (status && status.parentNode) status.parentNode.insertBefore(el, status.nextSibling);
    }
    el.textContent = TOWER_WITHOUT_OBS.has(selectedAsset)
      ? words('该塔为场址内已存在的塔位标记，无观测数据。页面展示的场址级数值取自 GFS 格点，以 M2 为订正基准，与该塔无计算关联。',
              'This mast is an existing tower position in the site with no observations. The site-level value shown comes from the GFS grid cell, corrected against station M2, with no computational link to this mast.')
      : '';
    el.style.display = el.textContent ? 'block' : 'none';
  }
  refreshTowerNote();
  window.addEventListener('twin-asset-selected', refreshTowerNote);
  window.addEventListener('show-hourly-browser', () => { document.body.classList.add('hourly-active'); load(); });
  new MutationObserver(() => { if (selection) render(); else labels(); }).observe(document.documentElement, {attributes: true, attributeFilter: ['lang']});
  labels();
  Promise.all([api('/api/status'), api('/api/weather/latest')]).then(([status, weather]) => { coverage = status.coverage; latest = weather; load(); }).catch(error => { find('#hourlyStatus').textContent = error.message; });
  setInterval(async () => {
    try {
      const weather = await api('/api/weather/latest');
      latest = weather;
      if (mode() === 'forecast' && document.body.classList.contains('hourly-active')) await load();
    } catch (error) { find('#hourlyStatus').textContent = words('更新失败，保留已选资料：', 'Update failed; selected saved data retained: ') + error.message; }
  }, 30000);
})();

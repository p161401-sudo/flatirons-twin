# 真实风光场站气象与风险管理原型

本课题唯一工作目录：`D:\SCI论文\风光场站气象风险管理孪生原型`。其他课题目录不属于本课题；可复用资料以来源校验值核对后的本地副本进入本目录。不要继续修改旧的会议演示目录。

## 文稿与系统入口

- **会议英文正式稿**：`论文素材 Paper Materials/送审材料 Submission Package/风光场站气象管理英文会议论文.docx`，当前为四页，含6图、6表、4个可编辑公式和8条参考文献，页边距统一；自动页码用于审阅，提交时按会务要求处理。
- **中文会议稿**：`论文素材 Paper Materials/送审材料 Submission Package/风光场站气象管理会议论文四页稿.docx`，本次保持原稿，供核对原有数据与表格。
- **中文完整研究稿**：`论文素材 Paper Materials/送审材料 Submission Package/风光场站气象风险管理论文.docx`，作为完整研究材料保留。送审目录按这三种用途分别保留一份Word。
- 新核对的场址官方介绍与地址页面保存在 `论文素材 Paper Materials/参考文献与审阅记录 References and Review/场址官方资料`，来源地址、下载时间、核验摘录与校验值见 `质量核验 QA/场址官方资料核验.json`。
- 文档导出使用`python-docx`、`pypdf`、LibreOffice、Poppler和`render_docx.py`；中文正文和补充材料已实际渲染并通过版面检查。GIS证据另有QGIS原生工程、PDF和PNG，位于`论文素材 Paper Materials/图表与空间证据 Figures and Spatial Evidence/QGIS原生输出`。

- 历史实验保存359组2026年第一季度配对及审计记录；本次网页与论文更新没有重新训练模型，也没有增加新的现场或未见时段检验，历史结果仍需按原报告的样本和限制解释。

- 查看系统：双击 `打开场站.cmd`，进入三维场景，在底部选择资料、日期和UTC小时，可前后逐时、逐日切换并播放跨日资料；服务窗口必须保持运行。
- 查看全部素材与证据链：`论文素材 Paper Materials/论文总览 Paper Overview.md`；功能与成熟度见 `论文素材 Paper Materials/研究核查与论文路线 Research Review and Roadmap.md`。
- 文稿用途、输入数据、程序和证据的目录分工统一见 `从这里开始.md`。
- 查看论文实图：`论文素材 Paper Materials/图表与空间证据 Figures and Spatial Evidence/figures`；9组场址、实测、事件、预测散点与网站交付图，每组包含300 dpi PNG与PDF；不使用热图、森林图或装饰性抽象图。
- 历史研究复现入口为 `复现研究.ps1`；本轮仅执行本机服务测试、浏览器操作与Word渲染，不把这些检查写成完整研究流程已经重新运行。

主张范围：公开资料支撑的现实场址空间表达、GIS空间组织、天气浏览、风险筛查和检查准备；不是逐台SCADA物理孪生或自动控制。QGIS原生地图已生成，但空间几何仍不等于设备运行状态，25 m/s演练与历史统计高风检验严格分开。

## System overview

This public-data prototype uses Flatirons Campus geometry, archived M2 observations, saved nearby KBJC observations and official NWS hourly forecasts. The default scene supports date/hour selection and sequential playback. GFS archive experiments and the original H0–H12 snapshot remain separate from the operational NWS feed.

The page supports local manual maintenance entries, not access to the site's existing work-order system. Device SCADA, actual production and automatic control are not connected. Weather selection does not imply measured device RPM, power or faults.

## Run

On Windows, double-click `打开场站.cmd`. Keep the service window running. The entry opens:

`http://127.0.0.1:8876/index.html`

The page must be served over HTTP because the browser loads local JavaScript modules. Opening `index.html` directly through `file://` is not supported.

## Main functions

- Full-screen Three.js scene with a local source-attributed imagery snapshot.
- Five mapped wind-turbine points, without measured rotor RPM; rotors stay still in hourly browsing mode.
- Thirteen mapped PV polygons, four meteorological towers, buildings, roads, a substation and a grid-interface object.
- Raycast and scene-label selection linked to one asset inspector.
- Overview, wind, solar and plan-view camera presets.
- M2 and saved KBJC observation history, and dated official NWS hourly forecasts; gaps remain empty.
- Previous/next hour and day controls, a 24-hour selector and cross-midnight sequential playback.
- Selected-hour weather linked to the asset inspector and manual-entry time; manual revisions persist locally.
- Chinese default interface and Chinese/English switch.
- Collapsible panels and responsive narrow-screen layout.

## Evidence roles

| Role | Meaning in this demonstration |
|---|---|
| Observed | M2 meteorological measurements |
| Forecast | Official NWS hourly forecasts; historical GFS is a separate archive |
| Model-derived | Transparent weather screening or site-capacity scenario |
| Simulated | Extreme-wind workflow rehearsal |
| Unavailable | No public Flatirons device-level source |

Hourly browsing does not animate measured rotor RPM or display actual power. The original GFS demonstration's capacity-level scenarios are not production measurements. OSM geometry and published equipment/capacity entries remain separate because public information does not uniquely bind every point to an actual device model.

## Rebuild the data bundle

`构建演示数据.py` reads the hash-registered local copies in `research/01 输入数据/imported` and regenerates `data.js` plus `来源清单.json`. It does not require the original project tree or write outside this directory.

```powershell
.\复现研究.ps1
```

The already generated `data.js` allows the demonstration folder to be copied and run without the parent research tree.

## Visual verification

The current operational tests are:

```powershell
python "质量核验 QA\业务功能测试.py"
```

These nine tests use isolated temporary databases for unit conversion, history imports, failed fetches, persistence, revision conflicts and HTTP access boundaries. They do not create records in the production database. Actual hourly-browser operation checks and screenshots are documented in `质量核验 QA/逐时浏览核验.json` and `网页截图 Web Screenshots`.

The older `验证演示.ps1` and its existing visual audit relate to the archived demonstration, including:

- desktop overview;
- selected wind turbine;
- selected PV area;
- H6 extreme-wind stress state;
- maintenance-data boundary;
- evidence drawer;
- Chinese risk view;
- narrow viewport;
- two animation frames.

Those earlier checks must not be substituted for a new test of the hourly browser or claimed as completed again in this update. This update checked the actual 637-pixel browser viewport; it does not claim a new 1440/390 dual-viewport test.

## Folder contents

- `index.html`, `styles.css`, `app.js`: interface and 3D scene.
- `data.js`: portable source-backed data bundle.
- `网站资源 Web Assets/`: local site imagery and attribution context.
- `外部依赖 Vendor Dependencies/`: pinned Three.js, OrbitControls and Lucide files.
- `构建演示数据.py`: deterministic data-bundle builder.
- `来源清单.json`: input paths, byte counts and SHA-256 hashes.
- `性能基准说明.md`: public interface references and adopted patterns.
- `质量核验 QA/`: repeatable visual QA script and audit.
- `网页截图 Web Screenshots/`: desktop, interaction and narrow-layout evidence.

## Primary sources

- NLR Flatirons Campus official facility material: `SRC-001`, `SRC-011`, `SRC-024`.
- NLR M2 MIDC meteorological observations: `SRC-026`.
- NOAA GFS public forecast archive: `SRC-002`.
- OpenStreetMap campus geometry snapshot, ODbL 1.0: `SRC-031`.
- Esri World Imagery snapshot for visual context: `IMG-001`.

The imagery credit is displayed in the interface. The imagery is used only as geographic context and is not treated as a scientific measurement layer.

## 2026年10月27日返修与数值预报回放

正式中英文会议稿及逐条回复位于 `论文素材 Paper Materials/送审材料 Submission Package/`，交付路径与文件校验值见 `最终交付清单.json`。本次补充对象数值回放、M2六高度逐时观测比较和概率校准敏感性分析；输入、结果与核验分别保存在原研究目录及 `质量核验 QA/返修核查/`，原359组预测及2025年冻结选择保持不变。

正常重启场站服务后，逐时查询的资料菜单可选择原始GFS研究预报或订正研究预报，按2026年1—3月日期和UTC小时回看，并切换场址对象。两个处理版本均保留来源、起报时间和有效时间；未采样小时显示缺失，不作插值。这里回放的是已保存的研究输出，目标为M2测站80 m风速，各对象共享场址参考资料；统计事件筛查与需结合当地风况、设备限值判断的设备风险分别保存。此次隔离测试未重启或替换用户正在使用的8876端口服务。

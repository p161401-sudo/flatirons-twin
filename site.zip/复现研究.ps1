param([switch]$Acquire, [switch]$Visual, [switch]$External)
$ErrorActionPreference = 'Stop'
$env:PYTHONDONTWRITEBYTECODE = '1'
$localPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
$lockedPython = 'C:\Users\19099\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$lockedPackages = Join-Path $PSScriptRoot '运行环境 Runtime\site-packages'
$python = $null
if (Test-Path -LiteralPath $localPython) {
    $python = $localPython
} elseif ((Test-Path -LiteralPath $lockedPython) -and (Test-Path -LiteralPath $lockedPackages)) {
    $python = $lockedPython
    $env:PYTHONPATH = $lockedPackages
} else {
    $adjacentPython = Join-Path (Split-Path $PSScriptRoot -Parent) 'WindFarm-RiskTwin Digital Power Plant\.venv\Scripts\python.exe'
    if (Test-Path -LiteralPath $adjacentPython) {
        $python = $adjacentPython
    }
}
if (-not $python) { throw 'Install the locked Python 3.12 environment or create .venv from requirements.txt.' }
$arguments = @((Join-Path $PSScriptRoot 'research\运行全部.py'))
if ($Acquire) { $arguments += '--acquire' }
if ($Visual) { $arguments += '--visual' }
if ($External) { $arguments += '--external' }
& $python @arguments
if ($LASTEXITCODE -ne 0) { throw "Research pipeline failed: $LASTEXITCODE" }